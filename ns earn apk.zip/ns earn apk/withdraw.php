<?php
require_once __DIR__ . '/Common/Config.php';

if (!is_logged_in()) {
    header("Location: Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT balance FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user_data = $result->fetch_assoc();

require_once __DIR__ . '/Common/header.php';
?>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<div class="min-h-screen bg-[#0b0f1a] pb-24 font-sans text-slate-300">
    
    <div class="bg-[#161d2f] pt-12 pb-10 px-6 rounded-b-[2.5rem] border-b border-white/5 shadow-2xl">
        <div class="flex items-center gap-4 mb-6">
            <a href="mine.php" class="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center border border-white/10">
                <i class="fas fa-chevron-left text-sm text-white"></i>
            </a>
            <h1 class="text-xl font-black text-white uppercase tracking-tighter italic">Withdraw Money</h1>
        </div>

        <div class="bg-gradient-to-br from-blue-600 to-indigo-700 p-6 rounded-3xl shadow-lg shadow-blue-900/20">
            <p class="text-white/70 text-[10px] font-black uppercase tracking-widest mb-1">Total Withdrawable Balance</p>
            <h2 class="text-4xl font-black text-white italic">₹ <?= number_format($user_data['balance'] ?? 0, 2) ?></h2>
        </div>
    </div>

    <div class="px-6 -mt-6">
        <div class="bg-[#1e293b] p-6 rounded-[2rem] border border-white/10 shadow-2xl">
            
            <form action="process_withdrawal.php" method="POST" class="space-y-6">
                
                <div>
                    <label class="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 mb-2 block">Withdrawal Method</label>
                    <div class="bg-[#0b0f1a] p-4 rounded-2xl border border-white/5 flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-500">
                                <i class="fas fa-university"></i>
                            </div>
                            <div>
                                <p class="text-xs font-bold text-white uppercase">UPI ID</p>
                                <p class="text-[9px] text-slate-500 uppercase">Not Set (Add first)</p>
                            </div>
                        </div>
                        <a href="add_upi.php" class="text-[10px] font-black text-blue-500 uppercase border-b border-blue-500/30">Change</a>
                    </div>
                </div>

                <div>
                    <label class="text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1 mb-2 block">Enter Amount</label>
                    <div class="relative">
                        <span class="absolute left-5 top-1/2 -translate-y-1/2 text-xl font-black text-slate-500">₹</span>
                        <input type="number" name="amount" placeholder="0.00" 
                               class="w-full bg-[#0b0f1a] border border-white/5 p-5 pl-12 rounded-2xl text-white font-black focus:border-blue-500 outline-none transition-all placeholder:text-slate-700">
                    </div>
                    <div class="flex justify-between mt-2 px-1">
                        <p class="text-[9px] text-slate-500 font-bold uppercase">Min: ₹100.00</p>
                        <p class="text-[9px] text-slate-500 font-bold uppercase">Max: ₹50,000.00</p>
                    </div>
                </div>

                <div class="bg-yellow-500/5 border border-yellow-500/20 p-4 rounded-2xl">
                    <p class="text-[10px] text-yellow-500/80 leading-relaxed font-bold uppercase italic">
                        <i class="fas fa-info-circle mr-1"></i> Withdrawal will be processed within 2-24 hours. Please check your UPI ID carefully before confirming.
                    </p>
                </div>

                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-5 rounded-2xl shadow-lg shadow-blue-900/40 uppercase tracking-widest text-xs active:scale-95 transition-all mt-4 border-b-4 border-blue-800">
                    Confirm Withdrawal
                </button>

            </form>
        </div>

        <a href="withdrawal_history.php" class="flex items-center justify-center gap-2 mt-8 text-slate-500 hover:text-white transition">
            <i class="fas fa-history text-xs"></i>
            <span class="text-[10px] font-black uppercase tracking-widest">View History</span>
        </a>
    </div>
</div>

<?php require_once __DIR__ . '/Common/bottom.php'; ?>
