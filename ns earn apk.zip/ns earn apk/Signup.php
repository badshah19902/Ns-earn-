<?php
require_once __DIR__ . '/Common/Config.php';

$message = "";

// --- AUTO REPAIR LOGIC START ---
// જો ટેબલમાં કોલમ ન હોય તો આ કોડ તેને જાતે બનાવી દેશે
function repairDatabase($conn) {
    $needed_columns = [
        "phone" => "ALTER TABLE users ADD COLUMN phone VARCHAR(15) UNIQUE AFTER username",
        "balance" => "ALTER TABLE users ADD COLUMN balance DECIMAL(10,2) DEFAULT 0.00 AFTER password",
        "today_points" => "ALTER TABLE users ADD COLUMN today_points DECIMAL(10,2) DEFAULT 0.00 AFTER balance",
        "refer_earn" => "ALTER TABLE users ADD COLUMN refer_earn DECIMAL(10,2) DEFAULT 0.00 AFTER today_points"
    ];

    foreach ($needed_columns as $col => $sql) {
        $check = $conn->query("SHOW COLUMNS FROM `users` LIKE '$col'");
        if ($check->num_rows == 0) {
            $conn->query($sql);
        }
    }
}
// --- AUTO REPAIR LOGIC END ---

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    repairDatabase($conn); // પહેલા ડેટાબેઝ રિપેર કરો

    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // ડુપ્લીકેટ મોબાઈલ ચેક
    $check_user = $conn->query("SELECT id FROM users WHERE phone = '$mobile'");
    
    if ($check_user->num_rows > 0) {
        $message = "<div class='bg-red-500/20 text-red-500 p-4 rounded-2xl border border-red-500/30 text-center font-bold mb-4'>આ નંબર પહેલેથી રજિસ્ટર્ડ છે!</div>";
    } else {
        // હવે ક્લીન ઇન્સર્ટ ક્વેરી
        $sql = "INSERT INTO users (username, phone, password, balance, today_points, refer_earn) VALUES (?, ?, ?, 0.00, 0.00, 0.00)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $username, $mobile, $password);
        
        if ($stmt->execute()) {
            $message = "<div class='bg-green-500/20 text-green-500 p-4 rounded-2xl border border-green-500/30 text-center font-bold mb-4'>રજિસ્ટ્રેશન સફળ! લોગિન કરો...</div>";
            echo "<script>setTimeout(() => { window.location='Login.php'; }, 2000);</script>";
        } else {
            $message = "<div class='bg-red-500/20 text-red-500 p-4 rounded-2xl border border-red-500/30 text-center font-bold mb-4'>Error: " . $conn->error . "</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Signup - NS EARN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .glass { background: rgba(22, 29, 47, 0.8); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.05); }
        .btn-3d { box-shadow: 0 10px 20px rgba(59, 130, 246, 0.3); transition: all 0.3s; }
        .btn-3d:active { transform: translateY(4px); box-shadow: 0 5px 10px rgba(59, 130, 246, 0.2); }
    </style>
</head>
<body class="bg-[#0b0f1a] text-white font-sans min-h-screen flex items-center justify-center p-6">

    <div class="max-w-md w-full">
        <div class="text-center mb-8">
            <h1 class="text-5xl font-black italic text-transparent bg-clip-text bg-gradient-to-b from-blue-400 to-blue-700">NS EARN</h1>
            <p class="text-slate-500 text-[10px] tracking-[0.4em] font-bold uppercase mt-2">Join the Elite Club</p>
        </div>

        <div class="glass p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
            <h2 class="text-2xl font-black text-center mb-6 tracking-tight">CREATE 3D ACCOUNT</h2>
            
            <?= $message ?>

            <form action="" method="POST" class="space-y-5">
                <div>
                    <label class="text-[10px] font-bold text-slate-500 uppercase ml-2 mb-1 block">Mobile Number</label>
                    <div class="relative">
                        <i class="fas fa-phone absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
                        <input type="number" name="mobile" required placeholder="10 આંકડાનો મોબાઈલ નંબર" 
                               class="w-full bg-black/40 border border-white/5 p-4 pl-12 rounded-2xl outline-none focus:border-blue-500/50 transition-all">
                    </div>
                </div>

                <div>
                    <label class="text-[10px] font-bold text-slate-500 uppercase ml-2 mb-1 block">Full Name</label>
                    <div class="relative">
                        <i class="fas fa-user absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
                        <input type="text" name="username" required placeholder="તમારું નામ" 
                               class="w-full bg-black/40 border border-white/5 p-4 pl-12 rounded-2xl outline-none focus:border-blue-500/50 transition-all">
                    </div>
                </div>

                <div>
                    <label class="text-[10px] font-bold text-slate-500 uppercase ml-2 mb-1 block">Create Password</label>
                    <div class="relative">
                        <i class="fas fa-lock absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
                        <input type="password" name="password" required placeholder="••••••••" 
                               class="w-full bg-black/40 border border-white/5 p-4 pl-12 rounded-2xl outline-none focus:border-blue-500/50 transition-all">
                    </div>
                </div>

                <button type="submit" class="w-full py-5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-2xl font-black text-lg btn-3d mt-4">
                    START EARNING NOW
                </button>
            </form>

            <div class="mt-8 text-center">
                <p class="text-slate-500 text-xs">પહેલેથી એકાઉન્ટ છે? <a href="Login.php" class="text-blue-500 font-bold ml-1">લોગિન કરો</a></p>
            </div>
        </div>
    </div>

</body>
</html>
