<?php
require_once __DIR__ . '/Common/Config.php';

// ૧. યુઝર ટેબલને સંપૂર્ણ અપડેટ કરવાની ક્વેરી
$queries = [
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS phone VARCHAR(15) UNIQUE AFTER username",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS balance DECIMAL(10,2) DEFAULT 0.00 AFTER password",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS today_points DECIMAL(10,2) DEFAULT 0.00 AFTER balance",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS refer_earn DECIMAL(10,2) DEFAULT 0.00 AFTER today_points"
];

echo "<h2>Database Updating...</h2>";

foreach ($queries as $sql) {
    if ($conn->query($sql)) {
        echo "<p style='color:green;'>SUCCESS: Column updated/verified.</p>";
    } else {
        echo "<p style='color:orange;'>INFO: " . $conn->error . " (કદાચ કોલમ પહેલેથી જ છે)</p>";
    }
}

echo "<br><b style='color:blue;'>હવે Signup.php ફરીથી ટ્રાય કરો!</b>";
echo "<br><a href='Signup.php'>Go to Signup Page</a>";
?>
