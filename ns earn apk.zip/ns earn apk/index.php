<?php
require_once __DIR__ . '/Common/Config.php';

if (!is_logged_in()) {
    header("Location: Login.php");
    exit();
}

$current_notice = null;

try {
    $check_table = $conn->query("SHOW TABLES LIKE 'notices'");
    if ($check_table->num_rows > 0) {
        $notice_query = "SELECT title, description FROM notices WHERE is_active = TRUE ORDER BY created_at DESC LIMIT 1";
        $notice_result = $conn->query($notice_query);
        if ($notice_result) {
            $current_notice = $notice_result->fetch_assoc();
        }
    }
} catch (Exception $e) {
    $current_notice = null;
}

require_once __DIR__ . '/Common/header.php';
?>

<div class="min-h-screen bg-[#0b0f1a] pb-24 text-white overflow-x-hidden">
    
    <div class="pt-10 pb-12 px-6 text-center">
        <h1 class="text-4xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-b from-orange-300 to-orange-600 drop-shadow-[0_5px_15px_rgba(234,179,8,0.4)]">
            Welcome, <?= htmlspecialchars($_SESSION['username'] ?? 'User') ?>!
        </h1>
    </div>

    <div class="px-6 mb-8">
        <?php if ($current_notice): ?>
            <div class="relative group">
                <div class="absolute -inset-0.5 bg-gradient-to-r from-orange-500 to-red-600 rounded-[2rem] blur opacity-30"></div>
                <div class="relative bg-gradient-to-br from-[#1e293b] to-[#0f172a] border border-white/10 p-6 rounded-[2rem] shadow-2xl">
                    <div class="flex items-start gap-4">
                        <div class="bg-orange-500/20 p-3 rounded-2xl text-orange-500">
                            <i class="fas fa-bullhorn text-xl"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-black text-orange-400 uppercase">
                                <?= htmlspecialchars($current_notice['title']) ?>
                            </h3>
                            <p class="text-slate-300 text-sm mt-1">
                                <?= htmlspecialchars($current_notice['description']) ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="bg-[#161d2f] border border-dashed border-white/10 p-6 rounded-[2rem] text-center">
                <p class="text-slate-500 text-xs">તમારું એકાઉન્ટ અત્યારે સુરક્ષિત છે. નવી અપડેટ અહીં દેખાશે.</p>
            </div>
        <?php endif; ?>
    </div>

    <div class="px-6 space-y-6 mb-10">
        <div class="relative group transform transition-all duration-500">
            <div class="absolute -inset-1 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-[2.5rem] blur opacity-25"></div>
            <div class="relative bg-[#161d2f] border border-white/5 p-8 rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.3)] flex flex-col items-center">
                <div class="absolute left-0 top-0 bottom-0 w-2 bg-blue-500 rounded-l-full"></div>
                <p class="text-slate-400 text-sm font-bold mb-2 uppercase tracking-widest">Total Balance</p>
                <h2 class="text-4xl font-black text-white user-balance-display">₹ <?= number_format($_SESSION['balance'] ?? 0, 2) ?></h2>
                <i class="fas fa-wallet absolute right-8 top-1/2 -translate-y-1/2 text-5xl text-white/5"></i>
            </div>
        </div>
    </div>

    <div class="px-6 mb-10">
        <h2 class="text-xs font-black text-slate-500 uppercase tracking-[0.2em] mb-4 ml-2">Quick Earning</h2>
        <div class="grid grid-cols-2 gap-4">
            
            <a href="instagram_reels.php" class="relative group overflow-hidden bg-gradient-to-br from-[#833ab4] via-[#fd1d1d] to-[#fcb045] p-[1px] rounded-[2rem] transition-transform active:scale-95 shadow-lg shadow-pink-500/20">
                <div class="bg-[#0b0f1a] rounded-[2rem] p-5 flex flex-col items-center justify-center h-full">
                    <div class="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mb-3">
                        <i class="fab fa-instagram text-3xl text-pink-500"></i>
                    </div>
                    <span class="text-sm font-black uppercase tracking-tighter">Watch Reels</span>
                    <span class="text-[10px] text-pink-500 font-bold mt-1">Earn Daily</span>
                </div>
            </a>

            <a href="youtube_tasks.php" class="relative group overflow-hidden bg-gradient-to-br from-[#ff0000] to-[#b91c1c] p-[1px] rounded-[2rem] transition-transform active:scale-95 shadow-lg shadow-red-500/20">
                <div class="bg-[#0b0f1a] rounded-[2rem] p-5 flex flex-col items-center justify-center h-full">
                    <div class="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mb-3">
                        <i class="fab fa-youtube text-3xl text-red-600"></i>
                    </div>
                    <span class="text-sm font-black uppercase tracking-tighter">YT Videos</span>
                    <span class="text-[10px] text-red-500 font-bold mt-1">High Reward</span>
                </div>
            </a>

        </div>
    </div>

    <div class="px-6">
        <div class="relative group">
            <div class="absolute -inset-1 bg-gradient-to-r from-emerald-600 to-green-400 rounded-[2.5rem] blur opacity-25"></div>
            <div class="relative bg-[#161d2f] border border-white/5 p-8 rounded-[2.5rem] flex flex-col items-center">
                <div class="absolute left-0 top-0 bottom-0 w-2 bg-emerald-500 rounded-l-full"></div>
                <p class="text-slate-400 text-sm font-bold mb-2 uppercase tracking-widest">Today's Points</p>
                <h2 class="text-4xl font-black text-white">0.00</h2>
            </div>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/Common/bottom.php'; ?>
