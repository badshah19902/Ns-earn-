<?php
require_once __DIR__ . '/Common/Config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $password = $_POST['password'];

    // ૧. ડેટાબેઝમાં મોબાઈલ નંબર શોધો
    $result = $conn->query("SELECT * FROM users WHERE phone = '$mobile'");

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // ૨. પાસવર્ડ ચેક કરો
        if (password_verify($password, $user['password'])) {
            // ૩. સેશન સેટ કરો
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['balance'] = $user['balance'];
            
            header("Location: index.php");
            exit();
        } else {
            echo "<script>alert('ખોટો પાસવર્ડ!'); window.location='Login.php';</script>";
        }
    } else {
        echo "<script>alert('આ મોબાઈલ નંબર મળ્યો નથી!'); window.location='Login.php';</script>";
    }
}
?>
