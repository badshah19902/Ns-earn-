<?php
require_once __DIR__ . '/Common/Config.php';
require_once __DIR__ . '/Common/header.php';
?>

<div class="min-h-screen bg-black flex flex-col overflow-hidden" style="height: 100vh;">
    <div class="p-4 bg-white/5 backdrop-blur-md border-b border-white/10 flex justify-between items-center z-50">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-gradient-to-tr from-[#f09433] via-[#dc2743] to-[#bc1888] rounded-2xl flex items-center justify-center shadow-lg">
                <i class="fab fa-instagram text-white text-xl"></i>
            </div>
            <div>
                <h2 class="text-white font-black text-sm uppercase tracking-tighter">NS Honista</h2>
                <div class="flex items-center gap-1">
                    <span class="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                    <span class="text-[9px] text-gray-400 font-bold uppercase tracking-widest">Fixed Mode</span>
                </div>
            </div>
        </div>
        <div class="flex gap-3">
             <button onclick="location.reload()" class="w-8 h-8 bg-white/5 rounded-xl flex items-center justify-center text-white text-xs">
                <i class="fas fa-sync-alt"></i>
             </button>
             <a href="index.php" class="w-8 h-8 bg-red-500/20 rounded-xl flex items-center justify-center text-red-500 text-xs">
                <i class="fas fa-times"></i>
             </a>
        </div>
    </div>

    <div class="flex-grow relative w-full h-full bg-[#0b0f1a]">
        <div id="insta-loader" class="absolute inset-0 flex flex-col items-center justify-center bg-[#0b0f1a] z-40 transition-opacity duration-500">
            <div class="relative w-20 h-20 mb-4">
                <div class="absolute inset-0 border-4 border-pink-500/20 rounded-full"></div>
                <div class="absolute inset-0 border-4 border-t-pink-500 rounded-full animate-spin"></div>
                <i class="fab fa-instagram absolute inset-0 flex items-center justify-center text-2xl text-pink-500"></i>
            </div>
            <p class="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em]">Resolving Connection...</p>
        </div>

        <iframe 
            src="https://www.instagram.com/reels/videos/?utm_source=pwa_embed" 
            class="w-full h-full border-none shadow-2xl"
            style="height: calc(100vh - 80px);"
            onload="document.getElementById('insta-loader').style.opacity='0'; setTimeout(()=>document.getElementById('insta-loader').style.display='none', 500);"
            sandbox="allow-forms allow-scripts allow-same-origin allow-popups"
        ></iframe>
    </div>
</div>

<?php require_once __DIR__ . '/Common/bottom.php'; ?>
