<?php
// ns-earn/Common/Config.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ૧. ડેટાબેઝ કનેક્શન (તમારા KSWEB MariaDB સેટિંગ્સ મુજબ)
$host = "127.0.0.1"; 
$user = "root";
$pass = "root"; // જો KSWEB માં પાસવર્ડ રાખ્યો હોય તો જ અહીં લખવો, અન્યથા ખાલી રાખવો
$db   = "ns_earn";

if (!isset($conn)) {
    $conn = new mysqli($host, $user, $pass, $db);
    if ($conn->connect_error) {
        die("ડેટાબેઝ કનેક્શન નિષ્ફળ: " . $conn->connect_error);
    }
}

// ૨. Redeclare એરરથી બચવા માટેની સુરક્ષા
if (!function_exists('is_logged_in')) {
    function is_logged_in() {
        return isset($_SESSION['user_id']);
    }
}

if (!function_exists('isUserLoggedIn')) {
    function isUserLoggedIn() {
        return isset($_SESSION['user_id']);
    }
}

if (!function_exists('redirectIfNotLoggedIn')) {
    function redirectIfNotLoggedIn($isAdmin = false) {
        if ($isAdmin) {
            if (!isset($_SESSION['admin_id'])) {
                header("Location: login.php");
                exit();
            }
        } else {
            if (!isset($_SESSION['user_id'])) {
                header("Location: Login.php");
                exit();
            }
        }
    }
}
?>
