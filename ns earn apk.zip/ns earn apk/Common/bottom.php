</main>
    <footer class="bg-gray-800 p-4 shadow-lg fixed bottom-0 left-0 w-full z-10">
        <nav class="flex justify-around items-center">
            <a href="index.php" class="flex flex-col items-center text-gray-400 hover:text-green-400 <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'text-green-400' : ''; ?>">
                <i class="fas fa-home text-xl"></i>
                <span class="text-xs mt-1">Home</span>
            </a>
            <a href="games.php" class="flex flex-col items-center text-gray-400 hover:text-green-400 <?php echo (basename($_SERVER['PHP_SELF']) == 'games.php' || basename($_SERVER['PHP_SELF']) == 'game_play.php') ? 'text-green-400' : ''; ?>">
                <i class="fas fa-gamepad text-xl"></i>
                <span class="text-xs mt-1">Games</span>
            </a>
            <a href="rewards.php" class="flex flex-col items-center text-gray-400 hover:text-green-400 <?php echo (basename($_SERVER['PHP_SELF']) == 'rewards.php') ? 'text-green-400' : ''; ?>">
                <i class="fas fa-trophy text-xl"></i>
                <span class="text-xs mt-1">Rewards</span>
            </a>
            <a href="mine.php" class="flex flex-col items-center text-gray-400 hover:text-green-400 <?php echo (basename($_SERVER['PHP_SELF']) == 'mine.php') ? 'text-green-400' : ''; ?>">
                <i class="fas fa-user text-xl"></i>
                <span class="text-xs mt-1">Mine</span>
            </a>
        </nav>
    </footer>
</body>
</html>