<?php
// ns-earn/Common/header.php
?>
<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title>NS Earn - Premium</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
        
        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background-color: #0b0f1a; 
            scrollbar-width: none;
        }
        body::-webkit-scrollbar { display: none; }

        .premium-nav {
            background: rgba(11, 15, 26, 0.85);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        #header-scroll-line {
            position: absolute;
            bottom: 0; left: 0; height: 2px; width: 0%;
            background: linear-gradient(90deg, #3b82f6, #8b5cf6, #ec4899);
            box-shadow: 0 0 10px rgba(59, 130, 246, 0.5);
            transition: opacity 0.3s ease;
        }

        .nav-scrolled {
            padding-top: 0.5rem !important;
            padding-bottom: 0.5rem !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        /* Coin Floating Animation */
        @keyframes coin-bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-3px); }
        }
        .coin-anim { animation: coin-bounce 2s infinite ease-in-out; }
    </style>
</head>
<body class="text-slate-200 overflow-x-hidden">

    <audio id="haptic-click" src="https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3" preload="auto"></audio>

    <nav id="main-nav" class="premium-nav sticky top-0 z-[100] px-5 py-4 transition-all duration-300">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            
            <div class="flex items-center">
                <a href="index.php" class="click-effect group relative">
                    <h1 class="text-xl font-black italic tracking-tighter flex items-center">
                        <span class="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-indigo-500">NS</span>
                        <span class="text-white ml-1 uppercase opacity-90">Earn</span>
                    </h1>
                </a>
            </div>

            <div class="flex items-center gap-3">
                
                <a href="wallet.php" class="click-effect flex items-center bg-white/5 border border-white/10 rounded-2xl py-1.5 px-3 active:scale-95 transition-all">
                    <div class="w-6 h-6 bg-gradient-to-tr from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center shadow-lg mr-2.5 coin-anim shadow-orange-500/20">
                        <i class="fas fa-coins text-[10px] text-white"></i>
                    </div>
                    <div class="flex flex-col leading-none">
                        <span class="text-[7px] font-bold text-slate-500 uppercase tracking-widest">Balance</span>
                        <span class="text-[13px] font-black text-white">₹<?= number_format($_SESSION['balance'] ?? 0, 2) ?></span>
                    </div>
                </a>

                <a href="mine.php" class="click-effect relative">
                    <div class="w-10 h-10 rounded-2xl border border-white/10 overflow-hidden shadow-2xl bg-slate-800">
                        <img src="https://ui-avatars.com/api/?name=<?= $_SESSION['username'] ?? 'User' ?>&background=1e293b&color=fff" class="w-full h-full object-cover">
                    </div>
                    <span class="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 border-4 border-[#0b0f1a] rounded-full"></span>
                </a>

            </div>
        </div>

        <div id="header-scroll-line"></div>
    </nav>

    <div class="pb-4"></div>

    <script>
        window.addEventListener('scroll', () => {
            const nav = document.getElementById('main-nav');
            const scrollLine = document.getElementById('header-scroll-line');
            const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = (winScroll / height) * 100;
            
            scrollLine.style.width = scrolled + "%";

            if (window.scrollY > 20) {
                nav.classList.add('nav-scrolled');
                scrollLine.style.opacity = "1";
            } else {
                nav.classList.remove('nav-scrolled');
                scrollLine.style.opacity = "0";
            }
        });

        // Updated Professional Click Sound Logic
        const clickSound = document.getElementById('haptic-click');
        // Setting volume to 0.5 for a professional soft feel
        clickSound.volume = 0.5;

        document.addEventListener('click', (e) => {
            const target = e.target.closest('.click-effect');
            if (target) {
                clickSound.currentTime = 0;
                clickSound.play().catch(() => {
                    console.log("Audio play deferred until user interaction.");
                });
                
                // Real 2026 Haptic (Light Tap)
                if (navigator.vibrate) navigator.vibrate(10);
            }
        });
    </script>
