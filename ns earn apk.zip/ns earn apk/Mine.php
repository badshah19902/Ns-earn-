<?php
require_once __DIR__ . '/Common/Config.php';

if (!is_logged_in()) {
    header("Location: Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT username, balance, created_at FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user_data = $result->fetch_assoc();

require_once __DIR__ . '/Common/header.php';
?>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<div class="min-h-screen bg-[#0b0f1a] pb-24 text-white font-sans">
    
    <div class="bg-gradient-to-br from-[#1e293b] to-[#0f172a] pt-12 pb-20 px-6 rounded-b-[3.5rem] shadow-2xl border-b border-white/5 relative">
        <div class="flex items-center gap-5">
            <div class="relative">
                <div class="absolute -inset-1 bg-gradient-to-tr from-blue-500 via-indigo-500 to-cyan-400 rounded-full blur opacity-40 animate-pulse"></div>
                <div class="relative w-20 h-20 bg-[#161d2f] rounded-full flex items-center justify-center text-3xl font-black text-white border-2 border-white/10 shadow-2xl overflow-hidden">
                    <span class="bg-clip-text text-transparent bg-gradient-to-b from-white to-blue-400">
                        <?= strtoupper(substr($user_data['username'] ?? 'M', 0, 1)) ?>
                    </span>
                </div>
            </div>
            
            <div>
                <h2 class="text-2xl font-black text-white tracking-tight uppercase"><?= htmlspecialchars($user_data['username'] ?? 'MEMBER') ?></h2>
                <div class="flex items-center gap-2 mt-1">
                    <span class="text-[9px] font-black text-blue-400 uppercase tracking-widest bg-blue-500/10 px-3 py-1 rounded-full border border-blue-500/20">Verified Profile</span>
                </div>
            </div>
        </div>
    </div>

    <div class="px-6 -mt-12">
        <div class="bg-[#161d2f] p-8 rounded-[2.5rem] border border-white/10 shadow-2xl relative overflow-hidden">
            <div class="flex justify-between items-center relative z-10">
                <div>
                    <p class="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Total Balance</p>
                    <h3 class="text-4xl font-black text-white tracking-tighter italic">₹ <?= number_format($user_data['balance'] ?? 0, 2) ?></h3>
                </div>
                <div class="w-16 h-16 bg-gradient-to-tr from-blue-600/20 to-indigo-600/20 rounded-2xl flex items-center justify-center border border-blue-500/30 shadow-inner">
                    <i class="fas fa-wallet text-3xl text-blue-500"></i>
                </div>
            </div>
            <div class="grid grid-cols-2 gap-4 mt-8 pt-6 border-t border-white/5 relative z-10">
                <a href="wallet.php" class="bg-blue-600 py-4 rounded-full flex items-center justify-center gap-2 text-white font-black text-[10px] uppercase shadow-lg shadow-blue-900/40 active:scale-95 transition">My Wallet</a>
                <a href="withdraw.php" class="bg-white/5 py-4 rounded-full flex items-center justify-center gap-2 text-white font-black text-[10px] uppercase border border-white/10 active:scale-95 transition">Withdraw</a>
            </div>
        </div>
    </div>

    <div class="px-6 mt-8 space-y-4">
        <div class="flex gap-4">
            <a href="history.php" class="flex-1 group">
                <div class="bg-gradient-to-r from-indigo-600/10 to-transparent border border-indigo-500/20 p-2 pl-2 pr-6 rounded-full flex items-center gap-3 active:scale-95 transition shadow-lg">
                    <div class="w-12 h-12 bg-indigo-500 rounded-full flex items-center justify-center shadow-lg shadow-indigo-900/40">
                        <i class="fas fa-history text-white text-sm"></i>
                    </div>
                    <div class="flex flex-col">
                        <span class="text-[10px] font-black text-white uppercase tracking-tighter">Balance</span>
                        <span class="text-[8px] font-bold text-indigo-400 uppercase">History</span>
                    </div>
                </div>
            </a>

            <a href="withdrawal_history.php" class="flex-1 group">
                <div class="bg-gradient-to-r from-emerald-600/10 to-transparent border border-emerald-500/20 p-2 pl-2 pr-6 rounded-full flex items-center gap-3 active:scale-95 transition shadow-lg">
                    <div class="w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center shadow-lg shadow-emerald-900/40">
                        <i class="fas fa-receipt text-white text-sm"></i>
                    </div>
                    <div class="flex flex-col">
                        <span class="text-[10px] font-black text-white uppercase tracking-tighter">Withdrawal</span>
                        <span class="text-[8px] font-bold text-emerald-400 uppercase">History</span>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <div class="px-6 mt-8 space-y-3">
        <div class="bg-[#161d2f] rounded-[2.5rem] border border-white/5 overflow-hidden shadow-xl">
            <a href="notifications.php" class="flex items-center justify-between p-6 border-b border-white/5 hover:bg-white/5 transition">
                <div class="flex items-center gap-4">
                    <div class="w-10 h-10 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-500 border border-blue-500/10">
                        <i class="fas fa-bell text-xs"></i>
                    </div>
                    <span class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Notifications</span>
                </div>
                <i class="fas fa-chevron-right text-slate-700 text-[10px]"></i>
            </a>

            <a href="rewards.php" class="flex items-center justify-between p-6 border-b border-white/5 hover:bg-white/5 transition">
                <div class="flex items-center gap-4">
                    <div class="w-10 h-10 bg-pink-500/10 rounded-full flex items-center justify-center text-pink-500 border border-pink-500/10">
                        <i class="fas fa-gift text-xs"></i>
                    </div>
                    <span class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Rewards Center</span>
                </div>
                <i class="fas fa-chevron-right text-slate-700 text-[10px]"></i>
            </a>
            
            <a href="http://t.me/NsEarnpvt" target="_blank" class="flex items-center justify-between p-6 hover:bg-white/5 transition">
                <div class="flex items-center gap-4">
                    <div class="w-10 h-10 bg-teal-500/10 rounded-full flex items-center justify-center text-teal-500 border border-teal-500/10">
                        <i class="fab fa-telegram-plane"></i>
                    </div>
                    <span class="text-[11px] font-black text-slate-300 uppercase tracking-wider">Customer Support</span>
                </div>
                <i class="fas fa-chevron-right text-slate-700 text-[10px]"></i>
            </a>
        </div>

        <a href="logout.php" class="flex items-center justify-center w-full py-5 bg-gradient-to-r from-red-500/10 to-red-600/5 text-red-500 font-black text-[10px] uppercase tracking-[0.3em] rounded-full border border-red-500/20 mt-6 shadow-lg active:scale-95 transition">
            <i class="fas fa-power-off mr-3"></i> Logout Account
        </a>
    </div>
</div>

<?php require_once __DIR__ . '/Common/bottom.php'; ?>
