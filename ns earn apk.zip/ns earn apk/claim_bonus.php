<?php
require_once __DIR__ . '/Common/Config.php';
header('Content-Type: application/json');

if (!is_logged_in()) {
    echo json_encode(['status' => 'error', 'message' => 'Login required']);
    exit();
}

$user_id = $_SESSION['user_id'];
$bonus_amount = 10.00; // બોનસની રકમ

try {
    // ૧. પહેલા ચેક કરો કે બોનસ પહેલેથી લેવાઈ ગયું છે?
    $stmt = $conn->prepare("SELECT registration_bonus_claimed FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user['registration_bonus_claimed'] == 1) {
        echo json_encode(['status' => 'error', 'message' => 'Already claimed!']);
        exit();
    }

    // ૨. ટ્રાન્ઝેક્શન શરૂ કરો (Data Integrity માટે)
    $conn->begin_transaction();

    // ૩. યુઝરનું બેલેન્સ વધારો અને ક્લેમ સ્ટેટસ ૧ કરો
    $update = $conn->prepare("UPDATE users SET balance = balance + ?, registration_bonus_claimed = 1 WHERE id = ?");
    $update->bind_param("di", $bonus_amount, $user_id);
    $update->execute();

    // ૪. ટ્રાન્ઝેક્શન હિસ્ટ્રીમાં એન્ટ્રી પાડો
    $log = $conn->prepare("INSERT INTO transactions (user_id, amount, type, source) VALUES (?, ?, 'credit', 'Registration Bonus')");
    $log->bind_param("id", $user_id, $bonus_amount);
    $log->execute();

    $conn->commit();

    // ૫. નવું બેલેન્સ મેળવો જેથી રીયલ-ટાઇમમાં બતાવી શકાય
    $new_balance_query = $conn->prepare("SELECT balance FROM users WHERE id = ?");
    $new_balance_query->bind_param("i", $user_id);
    $new_balance_query->execute();
    $new_balance = $new_balance_query->get_result()->fetch_assoc()['balance'];

    echo json_encode([
        'status' => 'success', 
        'message' => '₹10 added successfully!',
        'new_balance' => number_format($new_balance, 2)
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['status' => 'error', 'message' => 'Server Error: ' . $e->getMessage()]);
}
?>
