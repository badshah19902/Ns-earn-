<?php
require_once __DIR__ . '/Common/Config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && is_logged_in()) {
    $user_id = $_SESSION['user_id'];
    $score = intval($_POST['score']);
    
    // ગણતરી: ૧૦૦ પોઈન્ટ પર ૧ રૂપિયો
    $reward = floor($score / 100);

    if ($reward > 0) {
        $conn->begin_transaction();
        try {
            // વોલેટમાં પૈસા ઉમેરો
            $conn->query("UPDATE users SET balance = balance + $reward WHERE id = $user_id");
            
            // ટ્રાન્ઝેક્શન લોગ બનાવો
            $stmt = $conn->prepare("INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, 'credit', 'Block Puzzle Reward')");
            $stmt->bind_param("id", $user_id, $reward);
            $stmt->execute();
            
            $conn->commit();
            echo json_encode(['status' => 'success', 'added' => $reward]);
        } catch (Exception $e) {
            $conn->rollback();
        }
    }
}
?>
