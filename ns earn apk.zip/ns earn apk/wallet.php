<?php
require_once __DIR__ . '/Common/Config.php';

if (!is_logged_in()) {
    header("Location: Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
// છેલ્લું વિથડ્રોઅલ સ્ટેટસ મેળવવા માટે
$last_withdraw = $conn->query("SELECT status, amount FROM withdrawals WHERE user_id = '$user_id' ORDER BY id DESC LIMIT 1")->fetch_assoc();
$query = $conn->query("SELECT balance FROM users WHERE id = '$user_id'");
$user = $query->fetch_assoc();

require_once __DIR__ . '/Common/header.php';
?>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<div class="min-h-screen bg-[#0b0f1a] pb-32 text-white font-sans">
    
    <div class="p-6 flex items-center justify-between">
        <a href="mine.php" class="w-10 h-10 bg-[#161d2f] rounded-full flex items-center justify-center border border-white/5 shadow-lg">
            <i class="fas fa-chevron-left text-slate-400"></i>
        </a>
        <h1 class="text-sm font-black tracking-[0.3em] uppercase italic text-blue-500">Secure Wallet</h1>
        <div class="w-10 h-10 bg-blue-500/10 rounded-full flex items-center justify-center border border-blue-500/20">
            <i class="fas fa-fingerprint text-blue-500 text-xs"></i>
        </div>
    </div>

    <div class="px-6 space-y-6">
        
        <div class="relative group">
            <div class="absolute -inset-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-[3rem] blur opacity-20"></div>
            <div class="relative bg-[#161d2f] p-8 rounded-[3rem] border border-white/10 shadow-2xl overflow-hidden text-center">
                <div class="absolute -top-10 -right-10 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl"></div>
                
                <p class="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">Available Balance</p>
                <h2 class="text-5xl font-black text-white tracking-tighter mb-6 italic">₹ <?= number_format($user['balance'], 2) ?></h2>
                
                <div class="flex justify-center gap-3">
                    <div class="bg-white/5 px-4 py-2 rounded-full border border-white/5 flex items-center gap-2">
                        <i class="fas fa-coins text-yellow-500 text-[10px]"></i>
                        <span class="text-[9px] font-black uppercase tracking-tight text-slate-300">Winning: ₹<?= number_format($user['balance'] * 0.8, 2) ?></span>
                    </div>
                    <div class="bg-white/5 px-4 py-2 rounded-full border border-white/5 flex items-center gap-2">
                        <i class="fas fa-gift text-pink-500 text-[10px]"></i>
                        <span class="text-[9px] font-black uppercase tracking-tight text-slate-300">Bonus: ₹<?= number_format($user['balance'] * 0.2, 2) ?></span>
                    </div>
                </div>
            </div>
        </div>

        <?php if($last_withdraw): ?>
        <div class="bg-gradient-to-r from-blue-900/20 to-transparent p-4 rounded-3xl border border-blue-500/10 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center text-blue-400 text-xs">
                    <i class="fas fa-clock-rotate-left"></i>
                </div>
                <div>
                    <p class="text-[8px] font-black text-slate-500 uppercase tracking-widest">Last Withdrawal</p>
                    <p class="text-[10px] font-bold text-white uppercase tracking-tight">₹<?= $last_withdraw['amount'] ?> - <?= $last_withdraw['status'] ?></p>
                </div>
            </div>
            <a href="withdrawal_history.php" class="text-[8px] font-black text-blue-500 uppercase border-b border-blue-500/30">View All</a>
        </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 gap-4 mt-8">
            
            <a href="withdraw.php" class="group active:scale-95 transition-all">
                <div class="bg-blue-600 p-2 rounded-full flex items-center justify-between pr-8 shadow-xl shadow-blue-900/40">
                    <div class="flex items-center gap-4">
                        <div class="w-14 h-14 bg-white/10 rounded-full flex items-center justify-center border border-white/20">
                            <i class="fas fa-paper-plane text-white"></i>
                        </div>
                        <div>
                            <h3 class="font-black text-xs uppercase tracking-tight">Withdraw Funds</h3>
                            <p class="text-blue-200 text-[8px] font-bold uppercase tracking-widest">Fast & Secure Payout</p>
                        </div>
                    </div>
                    <i class="fas fa-arrow-right text-white/50 group-hover:translate-x-1 transition-transform"></i>
                </div>
            </a>

            <a href="history.php" class="group active:scale-95 transition-all">
                <div class="bg-[#161d2f] p-2 rounded-full flex items-center justify-between pr-8 border border-white/10 shadow-lg">
                    <div class="flex items-center gap-4">
                        <div class="w-14 h-14 bg-white/5 rounded-full flex items-center justify-center border border-white/5">
                            <i class="fas fa-list-ul text-slate-400"></i>
                        </div>
                        <div>
                            <h3 class="font-black text-xs uppercase tracking-tight text-white">Wallet Ledger</h3>
                            <p class="text-slate-500 text-[8px] font-bold uppercase tracking-widest">Check Full History</p>
                        </div>
                    </div>
                    <i class="fas fa-chevron-right text-slate-700"></i>
                </div>
            </a>

        </div>

        <div class="pt-8 border-t border-white/5">
            <div class="flex items-center justify-between bg-white/5 p-5 rounded-[2.5rem] border border-white/5">
                <div class="flex items-center gap-4">
                    <div class="w-10 h-10 bg-teal-500/10 rounded-full flex items-center justify-center text-teal-500 border border-teal-500/20">
                        <i class="fas fa-headset"></i>
                    </div>
                    <div>
                        <h4 class="text-[10px] font-black text-white uppercase tracking-wider">Facing Issues?</h4>
                        <p class="text-[8px] text-slate-500 font-bold uppercase">24/7 Support Available</p>
                    </div>
                </div>
                <a href="http://t.me/NsEarnpvt" class="bg-teal-500/10 text-teal-500 px-5 py-2 rounded-full text-[9px] font-black uppercase tracking-widest border border-teal-500/20">Chat Now</a>
            </div>
        </div>

    </div>

    <div class="mt-12 text-center">
        <div class="inline-flex items-center gap-2 text-slate-600 text-[8px] font-black tracking-[0.2em] uppercase">
            <i class="fas fa-lock"></i>
            End-to-End Encrypted Transactions
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/Common/bottom.php'; ?>
