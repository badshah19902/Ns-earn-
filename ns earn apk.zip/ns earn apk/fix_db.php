<?php
require_once __DIR__ . '/Common/Config.php';

// SQL ક્વેરી: ટેબલમાં નવી કોલમ ઉમેરવા માટે
$sql = "ALTER TABLE users ADD COLUMN registration_bonus_claimed TINYINT(1) DEFAULT 0";

if ($conn->query($sql) === TRUE) {
    echo "<h1 style='color:green;'>Success! નવી કોલમ ઉમેરાઈ ગઈ છે.</h1>";
    echo "<p>હવે તમે 'daily_task.php' પેજ પર જઈને બોનસ ક્લેમ કરી શકો છો.</p>";
} else {
    echo "<h1 style='color:red;'>Error:</h1> " . $conn->error;
    echo "<p>જો 'Duplicate column name' લખેલું આવે, તો તેનો અર્થ એ કે કોલમ પહેલેથી જ છે.</p>";
}

$conn->close();
?>
