<?php
require_once __DIR__ . '/Common/Config.php';

if (!is_logged_in()) {
    header("Location: Login.php");
    exit();
}

require_once __DIR__ . '/Common/header.php';
?>

<div class="min-h-screen bg-[#0b0f1a] pb-24 text-white font-sans">
    
    <div class="bg-gradient-to-br from-[#1e293b] to-[#0f172a] p-10 rounded-b-[3.5rem] shadow-2xl border-b border-white/5 text-center">
        <h1 class="text-3xl font-black bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 to-orange-500 tracking-tighter">REWARDS HUB</h1>
        <p class="text-slate-400 text-xs mt-1 uppercase tracking-widest font-bold">Earn extra with every move</p>
    </div>

    <div class="px-6 mt-10 grid grid-cols-1 gap-6">
        
        <a href="daily_task.php" class="relative group transform transition-all duration-300 active:scale-95">
            <div class="absolute -inset-0.5 bg-gradient-to-r from-emerald-400 to-green-600 rounded-3xl blur opacity-20 group-hover:opacity-40"></div>
            <div class="relative bg-[#161d2f] border border-white/10 p-6 rounded-3xl flex items-center justify-between shadow-[0_15px_30px_rgba(0,0,0,0.4)]">
                <div class="flex items-center gap-5">
                    <div class="w-14 h-14 bg-gradient-to-br from-emerald-500 to-green-700 rounded-2xl flex items-center justify-center text-2xl shadow-lg border border-white/20">
                        <i class="fas fa-tasks text-white"></i>
                    </div>
                    <div>
                        <h3 class="font-black text-lg">Daily Task</h3>
                        <p class="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Complete & Earn Daily</p>
                    </div>
                </div>
                <i class="fas fa-chevron-right text-slate-600 group-hover:text-emerald-400 transition"></i>
            </div>
        </a>

        <a href="gift.php" class="relative group transform transition-all duration-300 active:scale-95">
            <div class="absolute -inset-0.5 bg-gradient-to-r from-orange-400 to-red-500 rounded-3xl blur opacity-20 group-hover:opacity-40"></div>
            <div class="relative bg-[#161d2f] border border-white/10 p-6 rounded-3xl flex items-center justify-between shadow-[0_15px_30_rgba(0,0,0,0.4)]">
                <div class="flex items-center gap-5">
                    <div class="w-14 h-14 bg-gradient-to-br from-orange-500 to-red-600 rounded-2xl flex items-center justify-center text-2xl shadow-lg border border-white/20">
                        <i class="fas fa-gift text-white"></i>
                    </div>
                    <div>
                        <h3 class="font-black text-lg">Gift Code</h3>
                        <p class="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Redeem your bonus</p>
                    </div>
                </div>
                <i class="fas fa-chevron-right text-slate-600 group-hover:text-orange-400 transition"></i>
            </div>
        </a>

        <a href="refer.php" class="relative group transform transition-all duration-300 active:scale-95">
            <div class="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-3xl blur opacity-20 group-hover:opacity-40"></div>
            <div class="relative bg-[#161d2f] border border-white/10 p-6 rounded-3xl flex items-center justify-between shadow-[0_15px_30px_rgba(0,0,0,0.4)]">
                <div class="flex items-center gap-5">
                    <div class="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-700 rounded-2xl flex items-center justify-center text-2xl shadow-lg border border-white/20">
                        <i class="fas fa-user-plus text-white"></i>
                    </div>
                    <div>
                        <h3 class="font-black text-lg">Refer & Earn</h3>
                        <p class="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Get ₹10 per friend</p>
                    </div>
                </div>
                <i class="fas fa-chevron-right text-slate-600 group-hover:text-blue-400 transition"></i>
            </div>
        </a>

        <a href="social.php" class="relative group transform transition-all duration-300 active:scale-95">
            <div class="absolute -inset-0.5 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-3xl blur opacity-20 group-hover:opacity-40"></div>
            <div class="relative bg-[#161d2f] border border-white/10 p-6 rounded-3xl flex items-center justify-between shadow-[0_15px_30px_rgba(0,0,0,0.4)]">
                <div class="flex items-center gap-5">
                    <div class="w-14 h-14 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl flex items-center justify-center text-2xl shadow-lg border border-white/20">
                        <i class="fab fa-telegram-plane text-white"></i>
                    </div>
                    <div>
                        <h3 class="font-black text-lg">Follow Us</h3>
                        <p class="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Join Telegram & Win</p>
                    </div>
                </div>
                <i class="fas fa-chevron-right text-slate-600 group-hover:text-cyan-400 transition"></i>
            </div>
        </a>

    </div>
</div>

<?php require_once __DIR__ . '/Common/bottom.php'; ?>
