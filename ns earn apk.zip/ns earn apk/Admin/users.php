<?php
// ns-earn/admin/users.php
require_once __DIR__ . '/Common/admin_header.php';

// સમયને Hours:Min ફોર્મેટમાં ફેરવવાનું ફંક્શન
function formatAppTime($seconds) {
    if (!$seconds || $seconds < 0) return "00:00";
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds / 60) % 60);
    return sprintf("%02d:%02d", $hours, $minutes);
}

$message = '';
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// ૧. સ્ટેટસ બદલવાનું લોજિક
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_status'])) {
    $user_id = (int)$_POST['user_id'];
    $new_status = $_POST['new_status'];

    $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $user_id);
    if ($stmt->execute()) {
        $message = '<div class="bg-blue-600 text-white p-4 rounded-2xl mb-6 shadow-lg border border-white/10 flex items-center gap-3 animate-in fade-in duration-500">
            <i class="fas fa-check-circle text-xl"></i> 
            <span class="font-bold text-sm">સ્ટેટસ અપડેટ થઈ ગયું છે.</span>
        </div>';
    }
    $stmt->close();
}

// ૨. યુઝર ડેટા ફેચ કરવો
$users = [];
$query = "SELECT * FROM users";
if (!empty($search)) {
    $query .= " WHERE username LIKE '%$search%'";
}
$query .= " ORDER BY created_at DESC";

try {
    $result_users = $conn->query($query);
    if ($result_users) {
        while ($row = $result_users->fetch_assoc()) {
            $users[] = $row;
        }
    }
} catch (mysqli_sql_exception $e) {
    $message = '<div class="bg-red-500/20 text-red-400 p-4 rounded-2xl mb-6 border border-red-500/30">એરર: ' . $e->getMessage() . '</div>';
}
?>

<div class="max-w-[1400px] mx-auto p-4 md:p-8 space-y-8 bg-[#0a0f1c] min-h-screen text-gray-100">

    <div class="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div class="space-y-2">
            <h1 class="text-3xl md:text-5xl font-black tracking-tighter uppercase italic text-white">
                યુઝર <span class="text-blue-500">લિસ્ટ</span>
            </h1>
            <p class="text-gray-500 text-[10px] font-bold tracking-[0.2em] uppercase">Total: <?= count($users) ?> Members</p>
        </div>

        <form action="" method="GET" class="relative w-full lg:w-96 group">
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" 
                   placeholder="શોધો..." 
                   class="w-full bg-[#161d31] border border-gray-800 text-white rounded-2xl py-4 pl-12 pr-4 outline-none focus:border-blue-600 transition-all shadow-xl text-sm">
            <i class="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
        </form>
    </div>

    <?= $message ?>

    <div class="bg-[#111827] rounded-3xl border border-gray-800 shadow-2xl overflow-hidden">
        
        <div class="hidden md:block overflow-x-auto">
            <table class="w-full text-left">
                <thead class="bg-gray-900/50 border-b border-gray-800">
                    <tr>
                        <th class="px-6 py-5 text-[10px] font-black text-gray-500 uppercase">વિગત</th>
                        <th class="px-6 py-5 text-[10px] font-black text-gray-500 uppercase">પાસવર્ડ</th>
                        <th class="px-6 py-5 text-[10px] font-black text-gray-500 uppercase">વપરાશ સમય (H:M)</th>
                        <th class="px-6 py-5 text-[10px] font-black text-gray-500 uppercase">બેલેન્સ</th>
                        <th class="px-6 py-5 text-[10px] font-black text-gray-500 uppercase">સ્ટેટસ</th>
                        <th class="px-6 py-5 text-center text-[10px] font-black text-gray-500 uppercase">એક્શન</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-800/40">
                    <?php foreach ($users as $user): ?>
                    <tr class="hover:bg-blue-600/[0.02] transition-colors">
                        <td class="px-6 py-6">
                            <div class="flex items-center gap-4">
                                <div class="h-10 w-10 rounded-full bg-blue-600/10 flex items-center justify-center text-blue-500">
                                    <i class="fas fa-user text-sm"></i>
                                </div>
                                <div>
                                    <p class="font-bold text-white uppercase text-sm"><?= htmlspecialchars($user['username']) ?></p>
                                    <p class="text-[10px] text-gray-500 italic"><?= htmlspecialchars($user['mobile'] ?? $user['phone'] ?? 'No Number') ?></p>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-6">
                            <span class="bg-gray-800/50 px-3 py-1.5 rounded-lg border border-white/5 text-xs font-mono text-gray-300">
                                <?= htmlspecialchars($user['password'] ?? 'N/A') ?>
                            </span>
                        </td>
                        <td class="px-6 py-6 font-mono text-blue-400 font-bold">
                            <i class="far fa-clock mr-1 text-[10px]"></i> <?= formatAppTime($user['usage_time'] ?? 0) ?>
                        </td>
                        <td class="px-6 py-6 font-black text-yellow-500 italic">₹<?= number_format($user['points'], 2) ?></td>
                        <td class="px-6 py-6">
                            <span class="text-[9px] font-bold uppercase px-3 py-1 rounded-full <?= $user['status'] === 'active' ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500' ?>">
                                <?= $user['status'] ?>
                            </span>
                        </td>
                        <td class="px-6 py-6 text-center">
                            <form action="" method="POST">
                                <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                <input type="hidden" name="new_status" value="<?= $user['status'] === 'active' ? 'banned' : 'active' ?>">
                                <button type="submit" name="change_status" class="text-[10px] font-black border border-gray-700 px-4 py-2 rounded-xl hover:bg-white hover:text-black transition uppercase">
                                    <?= $user['status'] === 'active' ? 'Ban' : 'Unban' ?>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="md:hidden divide-y divide-gray-800/50">
            <?php foreach ($users as $user): ?>
            <div class="p-5 space-y-4">
                <div class="flex justify-between items-start">
                    <div class="flex items-center gap-3">
                        <div class="h-10 w-10 rounded-xl bg-gray-800 flex items-center justify-center text-blue-500">
                            <i class="fas fa-user"></i>
                        </div>
                        <div>
                            <p class="font-black text-white uppercase text-sm"><?= htmlspecialchars($user['username']) ?></p>
                            <p class="text-[10px] text-gray-500"><?= htmlspecialchars($user['mobile'] ?? 'No Number') ?></p>
                        </div>
                    </div>
                    <span class="text-[9px] font-bold uppercase px-2 py-1 rounded-md <?= $user['status'] === 'active' ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500' ?>">
                        <?= $user['status'] ?>
                    </span>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div class="bg-gray-800/30 p-3 rounded-2xl border border-white/5">
                        <p class="text-[8px] text-gray-500 font-bold uppercase mb-1">પાસવર્ડ</p>
                        <p class="text-[11px] font-mono text-gray-300 truncate"><?= htmlspecialchars($user['password'] ?? 'N/A') ?></p>
                    </div>
                    <div class="bg-blue-500/5 p-3 rounded-2xl border border-blue-500/10 text-right">
                        <p class="text-[8px] text-gray-500 font-bold uppercase mb-1">વપરાશ</p>
                        <p class="font-mono text-blue-400 font-bold text-[11px]"><?= formatAppTime($user['usage_time'] ?? 0) ?></p>
                    </div>
                </div>

                <div class="flex justify-between items-center bg-black/20 p-3 rounded-2xl border border-white/5">
                    <span class="text-[10px] text-gray-500 font-bold uppercase tracking-widest text-center">બેલેન્સ</span>
                    <span class="font-black text-yellow-500 italic text-lg">₹<?= number_format($user['points'], 2) ?></span>
                </div>
                <form action="" method="POST" class="w-full">
                    <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                    <input type="hidden" name="new_status" value="<?= $user['status'] === 'active' ? 'banned' : 'active' ?>">
                    <button type="submit" name="change_status" class="w-full py-3 rounded-2xl text-[10px] font-black uppercase border border-gray-700 bg-gray-800/50">
                        <?= $user['status'] === 'active' ? 'Ban User' : 'Unban User' ?>
                    </button>
                </form>
            </div>
            <?php endforeach; ?>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/Common/admin_footer.php'; ?>
