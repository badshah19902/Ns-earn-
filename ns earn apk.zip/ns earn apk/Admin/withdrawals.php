<?php
// ns-earn/admin/withdrawals.php
require_once __DIR__ . '/common/admin_header.php';

$message = '';

// Handle withdrawal request actions (accept/reject)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_withdrawal'])) {
    $withdrawal_id = (int)$_POST['withdrawal_id'];
    $action = $_POST['action']; // 'accept' or 'reject'

    if (!in_array($action, ['accept', 'reject'])) {
        $message = '<div class="bg-red-500 text-white p-3 rounded-md mb-4 flex items-center"><i class="fas fa-exclamation-circle mr-2"></i> Invalid action provided.</div>';
    } else {
        // Fetch withdrawal details to update user points if rejected
        $stmt_fetch_withdrawal = $conn->prepare("SELECT user_id, amount, status FROM withdrawals WHERE id = ?");
        $stmt_fetch_withdrawal->bind_param("i", $withdrawal_id);
        $stmt_fetch_withdrawal->execute();
        $result_withdrawal = $stmt_fetch_withdrawal->get_result();
        $withdrawal = $result_withdrawal->fetch_assoc();
        $stmt_fetch_withdrawal->close();

        if (!$withdrawal) {
            $message = '<div class="bg-red-500 text-white p-3 rounded-md mb-4 flex items-center"><i class="fas fa-exclamation-circle mr-2"></i> Withdrawal request not found.</div>';
        } elseif ($withdrawal['status'] !== 'pending') {
            $message = '<div class="bg-red-500 text-white p-3 rounded-md mb-4 flex items-center"><i class="fas fa-exclamation-circle mr-2"></i> This withdrawal request has already been processed.</div>';
        } else {
            $conn->begin_transaction();
            try {
                $new_status = ($action === 'accept') ? 'accepted' : 'rejected';

                // Update withdrawal status
                $stmt_update_withdrawal = $conn->prepare("UPDATE withdrawals SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
                $stmt_update_withdrawal->bind_param("si", $new_status, $withdrawal_id);
                if (!$stmt_update_withdrawal->execute()) {
                    throw new Exception("Error updating withdrawal status.");
                }
                $stmt_update_withdrawal->close();

                // Update related transaction status (initial withdrawal request transaction)
                $stmt_update_transaction = $conn->prepare("UPDATE transactions SET status = ? WHERE related_id = ? AND type = 'withdrawal_request'");
                $stmt_update_transaction->bind_param("si", $new_status, $withdrawal_id);
                if (!$stmt_update_transaction->execute()) {
                     throw new Exception("Error updating related transaction status.");
                }
                $stmt_update_transaction->close();


                if ($action === 'rejected') {
                    // Return points to user if rejected
                    $stmt_return_points = $conn->prepare("UPDATE users SET points = points + ? WHERE id = ?");
                    $stmt_return_points->bind_param("di", $withdrawal['amount'], $withdrawal['user_id']);
                    if (!$stmt_return_points->execute()) {
                        throw new Exception("Error returning points to user.");
                    }
                    $stmt_return_points->close();

                    // Log this as a new transaction for point return
                    $description_return = "Withdrawal request rejected, points returned.";
                    $type_return = "game_points"; // Treat as points added back
                    $status_return = "completed";
                    $stmt_log_return = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description, status) VALUES (?, ?, ?, ?, ?)");
                    $stmt_log_return->bind_param("idsis", $withdrawal['user_id'], $type_return, $withdrawal['amount'], $description_return, $status_return);
                    $stmt_log_return->execute();
                    $stmt_log_return->close();

                    $message = '<div class="bg-green-500 text-white p-3 rounded-md mb-4 flex items-center"><i class="fas fa-check-circle mr-2"></i> Withdrawal request rejected, points returned to user.</div>';
                } else {
                    // If accepted, optionally log a final 'withdrawal_processed' transaction
                    // This creates a second transaction entry for the same withdrawal event, indicating it moved from request to processed.
                    $description_processed = "Withdrawal processed via UPI: " . $withdrawal['upi_id'];
                    $type_processed = "withdrawal_processed";
                    $status_processed = "completed";
                    $stmt_log_processed = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description, status, related_id) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt_log_processed->bind_param("idsisi", $withdrawal['user_id'], $type_processed, $withdrawal['amount'], $description_processed, $status_processed, $withdrawal_id);
                    $stmt_log_processed->execute();
                    $stmt_log_processed->close();

                    $message = '<div class="bg-green-500 text-white p-3 rounded-md mb-4 flex items-center"><i class="fas fa-check-circle mr-2"></i> Withdrawal request accepted.</div>';
                }

                $conn->commit();

            } catch (Exception $e) {
                $conn->rollback();
                $message = '<div class="bg-red-500 text-white p-3 rounded-md mb-4 flex items-center"><i class="fas fa-exclamation-circle mr-2"></i> Error processing withdrawal: ' . htmlspecialchars($e->getMessage()) . '</div>';
            }
        }
    }
}

// Fetch all withdrawal requests
$withdrawals = [];
$result_withdrawals = $conn->query("
    SELECT w.id, w.user_id, u.username, w.upi_id, w.amount, w.status, w.created_at, w.updated_at
    FROM withdrawals w
    JOIN users u ON w.user_id = u.id
    ORDER BY w.created_at DESC
");
if ($result_withdrawals) {
    while ($row = $result_withdrawals->fetch_assoc()) {
        $withdrawals[] = $row;
    }
}
?>

<h1 class="text-3xl font-bold text-gray-200 mb-6">Withdrawal Requests</h1>

<?= $message ?>

<?php if (empty($withdrawals)): ?>
    <p class="text-gray-400 text-center">No withdrawal requests found.</p>
<?php else: ?>
    <div class="overflow-x-auto bg-gray-800 rounded-lg shadow-lg">
        <table class="min-w-full divide-y divide-gray-700">
            <thead class="bg-gray-700">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">User</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">UPI ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Amount</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Requested On</th>
                    <th class="px-6 py-3 text-center text-xs font-medium text-gray-300 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-700">
                <?php foreach ($withdrawals as $withdrawal): ?>
                    <tr class="hover:bg-gray-700">
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-300"><?= htmlspecialchars($withdrawal['id']) ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-200"><?= htmlspecialchars($withdrawal['username']) ?> (ID: <?= htmlspecialchars($withdrawal['user_id']) ?>)</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-300"><?= htmlspecialchars($withdrawal['upi_id']) ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-green-400 font-medium"><i class="fas fa-coins mr-1"></i> <?= htmlspecialchars(number_format($withdrawal['amount'], 2)) ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                            <?php
                            $status_color = '';
                            $status_icon = '';
                            switch ($withdrawal['status']) {
                                case 'pending':
                                    $status_color = 'text-yellow-400';
                                    $status_icon = 'fas fa-hourglass-half';
                                    break;
                                case 'accepted':
                                    $status_color = 'text-green-500';
                                    $status_icon = 'fas fa-check-circle';
                                    break;
                                case 'rejected':
                                    $status_color = 'text-red-500';
                                    $status_icon = 'fas fa-times-circle';
                                    break;
                            }
                            ?>
                            <span class="<?= $status_color ?>"><i class="<?= $status_icon ?> mr-1"></i> <?= ucfirst(htmlspecialchars($withdrawal['status'])) ?></span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-400"><?= date('M d, Y H:i', strtotime($withdrawal['created_at'])) ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                            <?php if ($withdrawal['status'] === 'pending'): ?>
                                <form action="withdrawals.php" method="POST" class="inline-block mr-2">
                                    <input type="hidden" name="withdrawal_id" value="<?= htmlspecialchars($withdrawal['id']) ?>">
                                    <input type="hidden" name="action" value="accept">
                                    <button type="submit" name="action_withdrawal" class="bg-green-600 hover:bg-green-700 text-white font-bold py-1 px-3 rounded text-xs transition-colors">
                                        <i class="fas fa-check mr-1"></i> Accept
                                    </button>
                                </form>
                                <form action="withdrawals.php" method="POST" class="inline-block">
                                    <input type="hidden" name="withdrawal_id" value="<?= htmlspecialchars($withdrawal['id']) ?>">
                                    <input type="hidden" name="action" value="reject">
                                    <button type="submit" name="action_withdrawal" class="bg-red-600 hover:bg-red-700 text-white font-bold py-1 px-3 rounded text-xs transition-colors">
                                        <i class="fas fa-times mr-1"></i> Reject
                                    </button>
                                </form>
                            <?php else: ?>
                                <span class="text-gray-500 italic">Processed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php
require_once __DIR__ . '/common/admin_footer.php';
?>