<?php
// ns-earn/admin/index.php
require_once __DIR__ . '/Common/admin_header.php'; 

// ડેટાબેઝમાંથી ડેટા લાવવા માટે વેરીએબલ્સ
$total_users = 0;
$total_points_in_system = 0.00;
$total_withdrawals_pending = 0.00;
$total_withdrawals_completed = 0.00; // નવું વેરીએબલ
$active_users = 0;

if ($conn) {
    // ૧. કુલ યુઝર્સની સંખ્યા
    $res = $conn->query("SELECT COUNT(id) FROM users");
    $total_users = $res->fetch_row()[0] ?? 0;

    // ૨. એક્ટિવ યુઝર્સ
    $res = $conn->query("SELECT COUNT(id) FROM users WHERE status = 'active'");
    $active_users = $res->fetch_row()[0] ?? 0;

    // ૩. સિસ્ટમમાં રહેલા કુલ પોઈન્ટ્સ
    $res = $conn->query("SELECT SUM(points) FROM users");
    $total_points_in_system = $res->fetch_row()[0] ?? 0.00;

    // ૪. પેન્ડિંગ ઉપાડ (Withdrawals)
    $res = $conn->query("SELECT SUM(amount) FROM withdrawals WHERE status = 'pending'");
    $total_withdrawals_pending = $res->fetch_row()[0] ?? 0.00;

    // ૫. કુલ કમ્પ્લીટ થયેલા ઉપાડ (Total Paid) - નવું લોજિક
    $res = $conn->query("SELECT SUM(amount) FROM withdrawals WHERE status = 'completed' OR status = 'success'");
    $total_withdrawals_completed = $res->fetch_row()[0] ?? 0.00;
}
?>

<div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
    <h1 class="text-3xl font-black text-white tracking-tight">એડમિન <span class="text-blue-500">ડેશબોર્ડ</span></h1>
    
    <div class="flex flex-wrap items-center gap-3">
        <a href="admin_task_add.php" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-xs font-black uppercase transition-all flex items-center gap-2 shadow-lg shadow-indigo-600/20">
            <i class="fas fa-plus-circle"></i> ટાસ્ક મેનેજર
        </a>

        <button onclick="window.location.reload();" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-black uppercase transition-all flex items-center gap-2 shadow-lg shadow-blue-600/20">
            <i class="fas fa-sync-alt animate-hover"></i> રિફ્રેશ ડેટા
        </button>
        
        <div class="text-xs font-bold text-gray-400 bg-gray-800 px-4 py-2 rounded-xl border border-gray-700 uppercase tracking-widest">
            અપડેટ સમય: <?= date('h:i A') ?>
        </div>
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    
    <div class="bg-gray-800 p-6 rounded-2xl border border-gray-700 shadow-lg hover:border-blue-500/50 transition-all group">
        <div class="flex justify-between items-start">
            <div>
                <h3 class="text-sm font-bold text-gray-400 uppercase">કુલ યુઝર્સ</h3>
                <p class="text-3xl font-black text-blue-500 mt-2"><?= number_format($total_users) ?></p>
            </div>
            <i class="fas fa-users text-2xl text-gray-600 group-hover:text-blue-500 transition-colors"></i>
        </div>
    </div>

    <div class="bg-gray-800 p-6 rounded-2xl border border-gray-700 shadow-lg hover:border-green-500/50 transition-all group">
        <div class="flex justify-between items-start">
            <div>
                <h3 class="text-sm font-bold text-gray-400 uppercase">એક્ટિવ યુઝર્સ</h3>
                <p class="text-3xl font-black text-green-500 mt-2"><?= number_format($active_users) ?></p>
            </div>
            <i class="fas fa-user-check text-2xl text-gray-600 group-hover:text-green-500 transition-colors"></i>
        </div>
    </div>

    <div class="bg-gray-800 p-6 rounded-2xl border border-gray-700 shadow-lg hover:border-indigo-500/50 transition-all group">
        <div class="flex justify-between items-start">
            <div>
                <h3 class="text-sm font-bold text-gray-400 uppercase">કુલ ચૂકવણી (Paid)</h3>
                <p class="text-3xl font-black text-indigo-400 mt-2">₹<?= number_format($total_withdrawals_completed, 2) ?></p>
            </div>
            <i class="fas fa-check-double text-2xl text-gray-600 group-hover:text-indigo-400 transition-colors"></i>
        </div>
    </div>

    <div class="bg-gray-800 p-6 rounded-2xl border border-gray-700 shadow-lg hover:border-red-500/50 transition-all group">
        <div class="flex justify-between items-start">
            <div>
                <h3 class="text-sm font-bold text-gray-400 uppercase">બાકી ચૂકવણી</h3>
                <p class="text-3xl font-black text-red-500 mt-2">₹<?= number_format($total_withdrawals_pending, 2) ?></p>
            </div>
            <i class="fas fa-clock text-2xl text-gray-600 group-hover:text-red-500 transition-colors"></i>
        </div>
    </div>

</div>

<div class="bg-gradient-to-r from-gray-800 to-gray-900 border border-gray-700 rounded-3xl p-8 shadow-2xl">
    <div class="flex items-center mb-6">
        <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center mr-4">
            <i class="fas fa-chart-pie text-white"></i>
        </div>
        <h2 class="text-xl font-black text-white italic uppercase tracking-wider">નાણાકીય વિહંગાવલોકન (System Economy)</h2>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div class="bg-black/20 p-6 rounded-2xl border border-white/5">
            <p class="text-gray-400 text-xs font-bold uppercase tracking-widest mb-1">કુલ વોલેટ બેલેન્સ</p>
            <p class="text-4xl font-black text-yellow-500">₹<?= number_format($total_points_in_system, 2) ?></p>
            <p class="text-[10px] text-gray-500 mt-2 font-bold italic">* યુઝર્સના વૉલેટમાં પડેલી કુલ રકમ.</p>
        </div>

        <div class="bg-black/20 p-6 rounded-2xl border border-white/5">
            <p class="text-gray-400 text-xs font-bold uppercase tracking-widest mb-1">કુલ સફળ વિથડ્રોઅલ</p>
            <p class="text-4xl font-black text-green-400">₹<?= number_format($total_withdrawals_completed, 2) ?></p>
            <p class="text-[10px] text-blue-400 mt-2 font-bold italic">* અત્યાર સુધીમાં ચૂકવેલી કુલ રકમ.</p>
        </div>

        <div class="bg-black/20 p-6 rounded-2xl border border-white/5">
            <p class="text-gray-400 text-xs font-bold uppercase tracking-widest mb-1">યુઝર દીઠ સરેરાશ</p>
            <?php $avg = ($total_users > 0) ? ($total_points_in_system / $total_users) : 0; ?>
            <p class="text-4xl font-black text-indigo-400"><?= number_format($avg, 2) ?> <span class="text-sm">Pts</span></p>
            <p class="text-[10px] text-gray-500 mt-2 font-bold italic">* સિસ્ટમ પોઈન્ટ્સ / કુલ યુઝર્સ</p>
        </div>
    </div>
</div>

<style>
    /* રિફ્રેશ બટન પર હોવર કરતા એનિમેશન */
    .animate-hover { transition: transform 0.5s ease; }
    button:hover .animate-hover { transform: rotate(180deg); }
</style>

<?php
require_once __DIR__ . '/Common/admin_footer.php';
?>
