<?php
// ns-earn/admin/Common/admin_header.php

// ૧. સાચો પાથ સેટ કરો
if (file_exists(__DIR__ . '/../../Common/Config.php')) {
    require_once __DIR__ . '/../../Common/Config.php';
} else if (file_exists(__DIR__ . '/../../common/config.php')) {
    require_once __DIR__ . '/../../common/config.php';
}

// ૨. જો સેશન ચાલુ ન હોય તો શરૂ કરો
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ૩. redirectIfNotLoggedIn ફંક્શન ચેક કરો અને બનાવો
if (!function_exists('redirectIfNotLoggedIn')) {
    function redirectIfNotLoggedIn($isAdmin = false) {
        if ($isAdmin) {
            if (!isset($_SESSION['admin_id'])) {
                header("Location: login.php");
                exit();
            }
        } else {
            if (!isset($_SESSION['user_id'])) {
                header("Location: login.php");
                exit();
            }
        }
    }
}

// ૪. હવે આ ફંક્શનને કોલ કરો
redirectIfNotLoggedIn(true); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NS Earn - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        /* Custom scrollbar for dark theme */
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #2d3748;
        }
        ::-webkit-scrollbar-thumb {
            background: #4a5568;
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #718096;
        }
    </style>
</head>
<body class="bg-gray-900 text-gray-100 min-h-screen flex">
    <aside class="w-64 bg-gray-800 shadow-lg p-6 flex flex-col justify-between fixed h-full z-20">
        <div>
            <div class="text-3xl font-bold text-yellow-400 mb-10 text-center">NS Admin</div>
            <nav class="space-y-4">
                <a href="index.php" class="flex items-center space-x-3 text-gray-300 hover:text-yellow-400 hover:bg-gray-700 p-3 rounded-md transition-colors">
                    <i class="fas fa-tachometer-alt text-xl"></i>
                    <span class="text-lg">Dashboard</span>
                </a>
                <a href="users.php" class="flex items-center space-x-3 text-gray-300 hover:text-yellow-400 hover:bg-gray-700 p-3 rounded-md transition-colors">
                    <i class="fas fa-users text-xl"></i>
                    <span class="text-lg">Users</span>
                </a>
                <a href="withdrawals.php" class="flex items-center space-x-3 text-gray-300 hover:text-yellow-400 hover:bg-gray-700 p-3 rounded-md transition-colors">
                    <i class="fas fa-hand-holding-usd text-xl"></i>
                    <span class="text-lg">Withdrawals</span>
                </a>
                
                <a href="send_notification.php" class="flex items-center space-x-3 text-gray-300 hover:text-blue-400 hover:bg-gray-700 p-3 rounded-md transition-colors">
                    <i class="fas fa-bell text-xl"></i>
                    <span class="text-lg">Send Notification</span>
                </a>

                <a href="admin_task_add.php" class="flex items-center space-x-3 text-gray-300 hover:text-green-400 hover:bg-gray-700 p-3 rounded-md transition-colors">
                    <i class="fas fa-tasks text-xl"></i>
                    <span class="text-lg">Manage Tasks</span>
                </a>
            </nav>
        </div>
        <div class="mt-8">
            <a href="logout.php" class="flex items-center space-x-3 text-red-400 hover:text-red-500 hover:bg-gray-700 p-3 rounded-md transition-colors">
                <i class="fas fa-sign-out-alt text-xl"></i>
                <span class="text-lg">Logout</span>
            </a>
        </div>
    </aside>

    <div class="flex-1 flex flex-col ml-64">
        <header class="bg-gray-800 p-4 shadow-md flex items-center justify-between z-10">
            <h1 class="text-2xl font-bold text-gray-200">Admin Panel</h1>
            <span class="text-gray-400">Welcome, <?= isset($_SESSION['admin_username']) ? htmlspecialchars($_SESSION['admin_username']) : 'Admin' ?></span>
        </header>
        <main class="flex-grow p-6">
