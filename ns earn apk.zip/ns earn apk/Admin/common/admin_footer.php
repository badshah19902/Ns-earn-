<?php
// ns-earn/admin/common/admin_footer.php
?>
        </main>
    </div>
</body>
</html>
<?php $conn->close(); ?>