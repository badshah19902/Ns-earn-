<?php
require_once __DIR__ . '/Common/Config.php';

// તમે જે યુઝરનેમ અને પાસવર્ડ રાખવા માંગતા હોય તે અહીં લખો
$admin_user = "admin"; 
$admin_pass = "admin123"; // તમારો મનપસંદ પાસવર્ડ

// પાસવર્ડને હેશ (Hash) કરો
$hashed_password = password_hash($admin_pass, PASSWORD_DEFAULT);

$sql = "INSERT INTO admin (username, password) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $admin_user, $hashed_password);

if ($stmt->execute()) {
    echo "<h2>Admin Created Successfully!</h2>";
    echo "Username: " . $admin_user . "<br>";
    echo "Password: " . $admin_pass . "<br>";
    echo "<br><a href='admin/login.php'>Go to Admin Login</a>";
} else {
    echo "Error: " . $conn->error;
}
?>
