<?php
// ns-earn/admin/logout.php
session_start();

// બધા સેશન વેરિએબલ્સ ખાલી કરો
$_SESSION = array();

// જો સેશન કુકીઝ હોય તો તેને પણ ડિલીટ કરો
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// સેશન પૂરો કરો
session_destroy();

// સીધું login.php પર મોકલી આપો
header("Location: login.php");
exit;
?>
