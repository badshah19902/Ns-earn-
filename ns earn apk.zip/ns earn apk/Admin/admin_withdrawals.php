<?php
require_once __DIR__ . '/Common/Config.php';

// અહીં તમારે એડમિન લોગિન ચેક મૂકવું જોઈએ

// ૧. સ્ટેટસ અપડેટ કરવાનું લોજિક
if (isset($_POST['update_status'])) {
    $withdrawal_id = $_POST['id'];
    $new_status = $_POST['status'];
    $user_id = $_POST['user_id'];
    $amount = $_POST['amount'];

    // જો Reject કરવામાં આવે, તો પૈસા યુઝરના વૉલેટમાં પાછા આપવા પડે
    if ($new_status == 'Rejected') {
        $conn->query("UPDATE users SET balance = balance + $amount WHERE id = '$user_id'");
    }

    $conn->query("UPDATE withdrawals SET status = '$new_status' WHERE id = '$withdrawal_id'");
    echo "<script>alert('Status Updated!'); window.location='admin_withdrawals.php';</script>";
}

// ૨. બધી રિક્વેસ્ટ મેળવો
$requests = $conn->query("SELECT w.*, u.username FROM withdrawals w JOIN users u ON w.user_id = u.id ORDER BY w.id DESC");
?>

<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Withdrawals</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
    <div class="max-w-5xl mx-auto">
        <h1 class="text-3xl font-bold mb-6 text-gray-800">Withdrawal Management</h1>

        <div class="bg-white shadow-md rounded-lg overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <th class="p-4">User</th>
                        <th class="p-4">Amount</th>
                        <th class="p-4">UPI ID</th>
                        <th class="p-4">Status</th>
                        <th class="p-4">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $requests->fetch_assoc()): ?>
                    <tr class="border-b">
                        <td class="p-4 font-bold"><?= $row['username'] ?></td>
                        <td class="p-4 text-green-600 font-bold">₹<?= $row['amount'] ?></td>
                        <td class="p-4 text-blue-600 underline"><?= $row['upi_id'] ?></td>
                        <td class="p-4">
                            <span class="px-3 py-1 rounded-full text-xs font-bold 
                                <?= $row['status'] == 'Pending' ? 'bg-yellow-200 text-yellow-800' : ($row['status'] == 'Success' ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800') ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td class="p-4">
                            <?php if($row['status'] == 'Pending'): ?>
                            <form method="POST" class="flex gap-2">
                                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                <input type="hidden" name="user_id" value="<?= $row['user_id'] ?>">
                                <input type="hidden" name="amount" value="<?= $row['amount'] ?>">
                                
                                <button name="update_status" value="1" onclick="this.form.status.value='Success'" class="bg-green-500 text-white px-3 py-1 rounded text-sm">Approve</button>
                                <button name="update_status" value="1" onclick="this.form.status.value='Rejected'" class="bg-red-500 text-white px-3 py-1 rounded text-sm">Reject</button>
                                <input type="hidden" name="status" value="">
                            </form>
                            <?php else: ?>
                                <span class="text-gray-400 text-sm">Processed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
