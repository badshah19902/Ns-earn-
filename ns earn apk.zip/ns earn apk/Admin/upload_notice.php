<?php
require_once __DIR__ . '/../Common/Config.php';

// અહીં તમારે એડમિન લોગિન ચેક ઉમેરવો જોઈએ (દા.ત. if(!is_admin()) { ... })

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['notice_image'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    
    // ઈમેજ અપલોડ લોજિક
    $target_dir = "../uploads/notices/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $file_name = time() . '_' . basename($_FILES["notice_image"]["name"]);
    $target_file = $target_dir . $file_name;
    $db_url = "uploads/notices/" . $file_name;

    if (move_uploaded_file($_FILES["notice_image"]["tmp_name"], $target_file)) {
        // જૂની બધી નોટિસને ઇન-એક્ટિવ કરો (જેથી નવી જ દેખાય)
        $conn->query("UPDATE notices SET is_active = FALSE");

        // નવી નોટિસ ડેટાબેઝમાં સેવ કરો
        $stmt = $conn->prepare("INSERT INTO notices (image_url, title, description, is_active) VALUES (?, ?, ?, TRUE)");
        $stmt->bind_param("sss", $db_url, $title, $description);
        
        if ($stmt->execute()) {
            $message = "<p class='text-green-500 font-bold'>Notice uploaded successfully!</p>";
        } else {
            $message = "<p class='text-red-500 font-bold'>Database error: " . $conn->error . "</p>";
        }
    } else {
        $message = "<p class='text-red-500 font-bold'>Sorry, there was an error uploading your file.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Upload Notice</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-[#0b0f1a] text-white font-sans min-h-screen flex items-center justify-center p-6">

    <div class="max-w-md w-full bg-[#161d2f] border border-white/10 p-8 rounded-[2.5rem] shadow-2xl">
        <div class="text-center mb-8">
            <h1 class="text-2xl font-black text-orange-500 uppercase tracking-widest">Post New Notice</h1>
            <p class="text-slate-400 text-sm mt-1">આ નોટિસ સીધી હોમ પેજ પર દેખાશે</p>
        </div>

        <?= $message ?>

        <form action="" method="POST" enctype="multipart/form-data" class="space-y-6 mt-4">
            <div>
                <label class="block text-slate-400 text-xs font-bold uppercase mb-2 ml-1">Notice Title</label>
                <input type="text" name="title" required placeholder="દા.ત. New Offer Available" 
                       class="w-full bg-[#0b0f1a] border border-white/10 rounded-2xl p-4 text-white focus:ring-2 focus:ring-orange-500 outline-none">
            </div>

            <div>
                <label class="block text-slate-400 text-xs font-bold uppercase mb-2 ml-1">Description</label>
                <textarea name="description" rows="3" placeholder="નોટિસ વિશે ટૂંકમાં લખો..." 
                          class="w-full bg-[#0b0f1a] border border-white/10 rounded-2xl p-4 text-white focus:ring-2 focus:ring-orange-500 outline-none"></textarea>
            </div>

            <div class="relative">
                <label class="block text-slate-400 text-xs font-bold uppercase mb-2 ml-1">Select 3D Banner Image</label>
                <div class="flex items-center justify-center w-full">
                    <label class="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-white/10 rounded-2xl cursor-pointer hover:bg-white/5 transition">
                        <div class="flex flex-col items-center justify-center pt-5 pb-6">
                            <i class="fas fa-cloud-upload-alt text-2xl text-slate-500 mb-2"></i>
                            <p class="text-xs text-slate-500">Click to upload image</p>
                        </div>
                        <input type="file" name="notice_image" class="hidden" required accept="image/*" />
                    </label>
                </div>
            </div>

            <button type="submit" class="w-full py-4 bg-gradient-to-r from-orange-500 to-red-600 rounded-2xl font-black shadow-lg shadow-orange-500/20 active:scale-95 transition">
                PUBLISH NOTICE
            </button>
            
            <a href="../index.php" class="block text-center text-slate-500 text-xs hover:text-white mt-4 transition">
                <i class="fas fa-arrow-left mr-1"></i> Back to Home
            </a>
        </form>
    </div>

</body>
</html>
