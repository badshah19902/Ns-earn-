<?php
require_once __DIR__ . '/Common/admin_header.php';

$message_status = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_notif'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $msg = $conn->real_escape_string($_POST['message']);
    $target = $_POST['target_user']; // 'all' અથવા ચોક્કસ user_id

    if ($target === 'all') {
        // બધા યુઝર્સને મોકલવા માટે
        $users = $conn->query("SELECT id FROM users");
        $stmt = $conn->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)");
        while ($u = $users->fetch_assoc()) {
            $stmt->bind_param("iss", $u['id'], $title, $msg);
            $stmt->execute();
        }
    } else {
        // એક જ યુઝરને મોકલવા માટે
        $stmt = $conn->prepare("INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $target, $title, $msg);
        $stmt->execute();
    }
    $message_status = "નોટિફિકેશન સફળતાપૂર્વક મોકલવામાં આવ્યું!";
}
?>

<div class="max-w-2xl mx-auto p-6 bg-[#111827] border border-gray-800 rounded-3xl mt-10">
    <h2 class="text-2xl font-black text-white mb-6 uppercase italic">મોકલો <span class="text-blue-500">નોટિફિકેશન</span></h2>
    
    <?php if($message_status): ?>
        <div class="bg-green-500/10 text-green-500 p-4 rounded-xl mb-4 border border-green-500/20 text-sm font-bold">
            <?= $message_status ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
        <div>
            <label class="text-xs font-bold text-gray-500 uppercase">ટાર્ગેટ યુઝર</label>
            <select name="target_user" class="w-full bg-[#161d31] border border-gray-700 text-white p-4 rounded-xl outline-none focus:border-blue-600 mt-2">
                <option value="all">બધા યુઝર્સ (All Users)</option>
                <?php
                $res = $conn->query("SELECT id, username FROM users");
                while($row = $res->fetch_assoc()) {
                    echo "<option value='{$row['id']}'>{$row['username']}</option>";
                }
                ?>
            </select>
        </div>
        <div>
            <label class="text-xs font-bold text-gray-500 uppercase">ટાઈટલ</label>
            <input type="text" name="title" required class="w-full bg-[#161d31] border border-gray-700 text-white p-4 rounded-xl outline-none focus:border-blue-600 mt-2" placeholder="દા.ત. નવું અપડેટ">
        </div>
        <div>
            <label class="text-xs font-bold text-gray-500 uppercase">મેસેજ</label>
            <textarea name="message" rows="4" required class="w-full bg-[#161d31] border border-gray-700 text-white p-4 rounded-xl outline-none focus:border-blue-600 mt-2" placeholder="તમારો મેસેજ અહીં લખો..."></textarea>
        </div>
        <button type="submit" name="send_notif" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-black py-4 rounded-xl uppercase transition-all shadow-lg shadow-blue-600/20">
            મોકલો (Send Now)
        </button>
    </form>
</div>

<?php require_once __DIR__ . '/Common/admin_footer.php'; ?>
