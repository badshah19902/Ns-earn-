<?php
// ૧. હેડર ફાઈલ ઈન્ક્લુડ કરો
require_once __DIR__ . '/Common/admin_header.php'; 

$message = "";

// ૨. નવો ટાસ્ક ઉમેરવાનું લોજિક
if (isset($_POST['add_task'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $reward = $_POST['reward'];
    $link = $_POST['link'];
    $icon = $_POST['icon'] ?: 'fas fa-tasks';

    $stmt = $conn->prepare("INSERT INTO tasks (title, description, reward, link, icon) VALUES (?, ?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("ssiss", $title, $description, $reward, $link, $icon);
        if ($stmt->execute()) {
            $message = "<div class='bg-green-500/20 text-green-400 p-4 rounded-xl mb-6 border border-green-500/20'>ટાસ્ક સફળતાપૂર્વક ઉમેરાઈ ગયો!</div>";
        } else {
            $message = "<div class='bg-red-500/20 text-red-400 p-4 rounded-xl mb-6 border border-red-500/20'>ભૂલ આવી: " . $conn->error . "</div>";
        }
    } else {
        $message = "<div class='bg-red-500/20 text-red-400 p-4 rounded-xl mb-6 border border-red-500/20'>ડેટાબેઝ ભૂલ: 'tasks' ટેબલ મળ્યું નથી!</div>";
    }
}

// ૩. ટાસ્ક ડિલીટ કરવાનું લોજિક
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM tasks WHERE id = $id");
    echo "<script>window.location.href='admin_task_add.php';</script>";
    exit();
}

// ૪. ટાસ્ક લિસ્ટ મેળવો (Error check સાથે)
$tasks = false;
try {
    $tasks = $conn->query("SELECT * FROM tasks ORDER BY id DESC");
} catch (Exception $e) {
    $message = "<div class='bg-yellow-500/20 text-yellow-400 p-4 rounded-xl mb-6 border border-yellow-500/20 underline'>
        મહત્વની સૂચના: તમારા ડેટાબેઝમાં 'tasks' ટેબલ બનાવવું પડશે. phpMyAdmin માં જઈને SQL ક્વેરી રન કરો.
    </div>";
}
?>

<div class="mb-8">
    <h1 class="text-3xl font-black text-white tracking-tight">ટાસ્ક <span class="text-blue-500">મેનેજર</span></h1>
</div>

<?php echo $message; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    
    <div class="lg:col-span-1">
        <form method="POST" class="bg-gray-800 p-6 rounded-2xl border border-gray-700 shadow-xl">
            <h2 class="text-xl font-black text-white mb-6 uppercase italic">નવો ટાસ્ક</h2>
            <div class="space-y-4">
                <input type="text" name="title" placeholder="ટાસ્કનું નામ" class="w-full bg-gray-900 text-white p-3 rounded-xl border border-gray-700 outline-none focus:border-blue-500" required>
                <input type="number" step="0.01" name="reward" placeholder="રિવોર્ડ (દા.ત. 10.00)" class="w-full bg-gray-900 text-white p-3 rounded-xl border border-gray-700 outline-none focus:border-blue-500" required>
                <input type="text" name="link" placeholder="લિંક (https://...)" class="w-full bg-gray-900 text-white p-3 rounded-xl border border-gray-700 outline-none focus:border-blue-500" required>
                <textarea name="description" placeholder="વિગત..." class="w-full bg-gray-900 text-white p-3 rounded-xl border border-gray-700 outline-none focus:border-blue-500 h-20"></textarea>
                <button type="submit" name="add_task" class="w-full bg-blue-600 text-white font-black py-4 rounded-xl hover:bg-blue-700 transition uppercase text-xs">Publish Task</button>
            </div>
        </form>
    </div>

    <div class="lg:col-span-2">
        <div class="bg-gray-800 rounded-2xl border border-gray-700 shadow-xl overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-gray-700 text-gray-400 text-xs uppercase">
                    <tr>
                        <th class="p-5">ટાસ્ક</th>
                        <th class="p-5">રિવોર્ડ</th>
                        <th class="p-5 text-right">એક્શન</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-700">
                    <?php if($tasks && $tasks->num_rows > 0): ?>
                        <?php while($row = $tasks->fetch_assoc()): ?>
                        <tr class="hover:bg-gray-700/30">
                            <td class="p-5 text-white font-bold"><?= htmlspecialchars($row['title']) ?></td>
                            <td class="p-5 text-yellow-500 font-bold">₹<?= $row['reward'] ?></td>
                            <td class="p-5 text-right">
                                <a href="?delete=<?= $row['id'] ?>" class="text-red-500" onclick="return confirm('ડિલીટ કરવો છે?')"><i class="fas fa-trash-alt"></i></a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="3" class="p-10 text-center text-gray-500 italic">કોઈ ટાસ્ક મળ્યા નથી.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/Common/admin_footer.php'; ?>
