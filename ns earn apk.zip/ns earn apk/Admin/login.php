<?php
// ૧. સેશન શરૂ કરો
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ૨. પાથ સેટ કરો અને Config.php લોડ કરો
$config_path = dirname(__DIR__) . '/Common/Config.php';

if (file_exists($config_path)) {
    require_once $config_path;
} else {
    die("Error: Config.php મળી નથી. પાથ ચેક કરો: " . $config_path);
}

// ૩. isAdminLoggedIn ફંક્શન અહીં જ વ્યાખ્યાયિત કરો જેથી એરર ના આવે
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']);
}

// ૪. જો એડમિન પહેલેથી લોગિન હોય તો ડેશબોર્ડ પર મોકલો
if (isAdminLoggedIn()) {
    header("Location: index.php");
    exit();
}

$error_message = '';

// ૫. લોગિન પ્રોસેસ
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        $error_message = "યુઝરનેમ અને પાસવર્ડ લખો.";
    } else {
        // એડમિન ટેબલમાંથી ડેટા ચેક કરો
        $stmt = $conn->prepare("SELECT id, username, password FROM admin WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $admin = $result->fetch_assoc();
            // પાસવર્ડ ચેક કરો
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];
                header("Location: index.php");
                exit();
            } else {
                $error_message = "પાસવર્ડ ખોટો છે!";
            }
        } else {
            $error_message = "આ યુઝરનેમ ધરાવતો એડમિન નથી!";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - NS Earn</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-[#0b0f1a] text-white min-h-screen flex items-center justify-center p-6">

    <div class="max-w-md w-full">
        <div class="bg-gray-800/50 p-8 rounded-[2rem] border border-white/10 shadow-2xl backdrop-blur-md">
            <h1 class="text-3xl font-black text-yellow-500 text-center mb-2">ADMIN</h1>
            <p class="text-slate-400 text-center text-xs font-bold uppercase tracking-widest mb-8">Secure Access Only</p>

            <?php if ($error_message): ?>
                <div class="bg-red-500/20 text-red-500 p-3 rounded-xl border border-red-500/30 text-sm mb-6 text-center">
                    <i class="fas fa-exclamation-triangle mr-2"></i> <?= $error_message ?>
                </div>
            <?php endif; ?>

            <form action="" method="POST" class="space-y-6">
                <div>
                    <label class="text-[10px] font-bold text-slate-400 uppercase ml-2 mb-1 block">Admin Username</label>
                    <input type="text" name="username" required placeholder="Enter Username"
                           class="w-full bg-black/40 border border-white/10 p-4 rounded-2xl outline-none focus:border-yellow-500 transition-all">
                </div>

                <div>
                    <label class="text-[10px] font-bold text-slate-400 uppercase ml-2 mb-1 block">Password</label>
                    <input type="password" name="password" required placeholder="••••••••"
                           class="w-full bg-black/40 border border-white/10 p-4 rounded-2xl outline-none focus:border-yellow-500 transition-all">
                </div>

                <button type="submit" class="w-full py-4 bg-yellow-500 hover:bg-yellow-600 text-black font-black rounded-2xl shadow-lg transition-all active:scale-95">
                    LOG IN TO PANEL
                </button>
            </form>
        </div>
    </div>

</body>
</html>
