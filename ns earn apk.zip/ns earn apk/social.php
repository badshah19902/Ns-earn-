<?php
require_once __DIR__ . '/Common/Config.php';

if (!is_logged_in()) {
    header("Location: Login.php");
    exit();
}

require_once __DIR__ . '/Common/header.php';
?>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<div class="min-h-screen bg-[#0b0f1a] pb-24 text-white font-sans">
    
    <div class="bg-gradient-to-br from-[#1e293b] to-[#0f172a] p-10 rounded-b-[3.5rem] shadow-2xl border-b border-white/5 text-center">
        <h1 class="text-3xl font-black bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500 tracking-tighter uppercase">Social Media</h1>
        <p class="text-slate-400 text-xs mt-1 uppercase tracking-widest font-bold">Connect with our official handles</p>
    </div>

    <div class="px-6 mt-10 grid grid-cols-1 gap-6">
        
        <a href="https://www.instagram.com/7.fx_levi?igsh=MWxmaThxajFhbnZ0bA==" target="_blank" class="relative group transform transition-all duration-300 active:scale-95">
            <div class="absolute -inset-0.5 bg-gradient-to-r from-pink-500 to-purple-600 rounded-3xl blur opacity-20 group-hover:opacity-40"></div>
            <div class="relative bg-[#161d2f] border border-white/10 p-6 rounded-3xl flex items-center justify-between shadow-[0_15px_30px_rgba(0,0,0,0.4)]">
                <div class="flex items-center gap-5">
                    <div class="w-14 h-14 bg-gradient-to-br from-pink-500 to-purple-700 rounded-2xl flex items-center justify-center text-2xl shadow-lg border border-white/20">
                        <i class="fab fa-instagram text-white"></i>
                    </div>
                    <div>
                        <h3 class="font-black text-lg">Instagram</h3>
                        <p class="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Follow @7.fx_levi</p>
                    </div>
                </div>
                <i class="fas fa-chevron-right text-slate-600 group-hover:text-pink-400 transition"></i>
            </div>
        </a>

        <a href="https://t.me/nsearnpvt1" target="_blank" class="relative group transform transition-all duration-300 active:scale-95">
            <div class="absolute -inset-0.5 bg-gradient-to-r from-blue-400 to-blue-600 rounded-3xl blur opacity-20 group-hover:opacity-40"></div>
            <div class="relative bg-[#161d2f] border border-white/10 p-6 rounded-3xl flex items-center justify-between shadow-[0_15px_30px_rgba(0,0,0,0.4)]">
                <div class="flex items-center gap-5">
                    <div class="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl flex items-center justify-center text-2xl shadow-lg border border-white/20">
                        <i class="fab fa-telegram-plane text-white"></i>
                    </div>
                    <div>
                        <h3 class="font-black text-lg">Telegram Channel</h3>
                        <p class="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Official Updates</p>
                    </div>
                </div>
                <i class="fas fa-chevron-right text-slate-600 group-hover:text-blue-400 transition"></i>
            </div>
        </a>

        <a href="https://t.me/+HE10I5VXvVo0Yjk9" target="_blank" class="relative group transform transition-all duration-300 active:scale-95">
            <div class="absolute -inset-0.5 bg-gradient-to-r from-teal-400 to-emerald-500 rounded-3xl blur opacity-20 group-hover:opacity-40"></div>
            <div class="relative bg-[#161d2f] border border-white/10 p-6 rounded-3xl flex items-center justify-between shadow-[0_15px_30px_rgba(0,0,0,0.4)]">
                <div class="flex items-center gap-5">
                    <div class="w-14 h-14 bg-gradient-to-br from-teal-500 to-emerald-700 rounded-2xl flex items-center justify-center text-2xl shadow-lg border border-white/20">
                        <i class="fas fa-users text-white"></i>
                    </div>
                    <div>
                        <h3 class="font-black text-lg">Telegram Group</h3>
                        <p class="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Community Chat</p>
                    </div>
                </div>
                <i class="fas fa-chevron-right text-slate-600 group-hover:text-teal-400 transition"></i>
            </div>
        </a>

        <a href="https://youtube.com/@badshahzxo?si=WZzWc0N9G4T30yOU" target="_blank" class="relative group transform transition-all duration-300 active:scale-95">
            <div class="absolute -inset-0.5 bg-gradient-to-r from-red-500 to-orange-600 rounded-3xl blur opacity-20 group-hover:opacity-40"></div>
            <div class="relative bg-[#161d2f] border border-white/10 p-6 rounded-3xl flex items-center justify-between shadow-[0_15px_30px_rgba(0,0,0,0.4)]">
                <div class="flex items-center gap-5">
                    <div class="w-14 h-14 bg-gradient-to-br from-red-500 to-red-700 rounded-2xl flex items-center justify-center text-2xl shadow-lg border border-white/20">
                        <i class="fab fa-youtube text-white"></i>
                    </div>
                    <div>
                        <h3 class="font-black text-lg">YouTube</h3>
                        <p class="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Subscribe Channel</p>
                    </div>
                </div>
                <i class="fas fa-chevron-right text-slate-600 group-hover:text-red-400 transition"></i>
            </div>
        </a>

    </div>

    <div class="px-6 mt-12 text-center">
        <a href="mine.php" class="text-slate-500 text-[10px] font-black uppercase tracking-[0.3em] hover:text-white transition">
            <i class="fas fa-arrow-left mr-2"></i> Return to Profile
        </a>
    </div>
</div>

<?php require_once __DIR__ . '/Common/bottom.php'; ?>
