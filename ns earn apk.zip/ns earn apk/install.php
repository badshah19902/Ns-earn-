<?php
// ns-earn/install.php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = '127.0.0.1';
$user = 'root';
$pass = 'root';
$dbname = 'ns_earn'; // Default database name

$mysqli = @new mysqli($host, $user, $pass);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error . "<br>Please ensure MySQL is running and root user has 'root' password or update common/config.php.");
}

echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NS Earn - Installation</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-900 text-gray-100 min-h-screen flex items-center justify-center">
    <div class="bg-gray-800 p-8 rounded-lg shadow-xl w-full max-w-md text-center">
        <h2 class="text-3xl font-bold text-yellow-400 mb-6">NS Earn Installation</h2>';

// Check if database exists, create if not
$db_exists_query = "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ?";
$stmt = $mysqli->prepare($db_exists_query);
$stmt->bind_param("s", $dbname);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows == 0) {
    // Database does not exist, create it
    $create_db_sql = "CREATE DATABASE IF NOT EXISTS `{$dbname}`";
    if ($mysqli->query($create_db_sql) === TRUE) {
        echo "<p class='text-green-500 mb-2'><i class='fas fa-check-circle mr-2'></i>Database '{$dbname}' created successfully.</p>";
    } else {
        die("<p class='text-red-500'><i class='fas fa-times-circle mr-2'></i>Error creating database: " . $mysqli->error . "</p>");
    }
} else {
    echo "<p class='text-blue-400 mb-2'><i class='fas fa-info-circle mr-2'></i>Database '{$dbname}' already exists.</p>";
}
$stmt->close();

// Connect to the newly created/existing database
$mysqli->select_db($dbname);

// Table creation SQL
$tables_sql = [
    "CREATE TABLE IF NOT EXISTS `users` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `username` VARCHAR(255) UNIQUE NOT NULL,
        `password` VARCHAR(255) NOT NULL,
        `points` DECIMAL(10, 2) DEFAULT 0.00,
        `upi_id` VARCHAR(255) NULL,
        `status` ENUM('active', 'banned') DEFAULT 'active',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )",
    "CREATE TABLE IF NOT EXISTS `admin` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `username` VARCHAR(255) UNIQUE NOT NULL,
        `password` VARCHAR(255) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "CREATE TABLE IF NOT EXISTS `games` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `name` VARCHAR(255) NOT NULL,
        `description` TEXT,
        `base_points` INT DEFAULT 10,
        `image` VARCHAR(255) NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )",
    "CREATE TABLE IF NOT EXISTS `transactions` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `user_id` INT NOT NULL,
        `type` ENUM('game_points', 'withdrawal_request', 'withdrawal_processed') NOT NULL,
        `amount` DECIMAL(10, 2) NOT NULL,
        `description` TEXT,
        `status` ENUM('pending', 'completed', 'rejected') DEFAULT 'completed',
        `related_id` INT NULL COMMENT 'ID of game or withdrawal',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    )",
    "CREATE TABLE IF NOT EXISTS `withdrawals` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `user_id` INT NOT NULL,
        `upi_id` VARCHAR(255) NOT NULL,
        `amount` DECIMAL(10, 2) NOT NULL,
        `status` ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
        `transaction_id` INT NULL COMMENT 'Reference to transactions table',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    )"
];

foreach ($tables_sql as $sql) {
    if ($mysqli->query($sql) === TRUE) {
        echo "<p class='text-green-500 text-sm mb-1'><i class='fas fa-check-circle mr-1'></i>Table created/verified successfully.</p>";
    } else {
        die("<p class='text-red-500'><i class='fas fa-times-circle mr-2'></i>Error creating table: " . $mysqli->error . "</p>");
    }
}

// Insert default admin credentials if not exists
$admin_username = 'admin';
$admin_password = password_hash('admin123', PASSWORD_DEFAULT); // Default admin password

$check_admin_sql = "SELECT id FROM `admin` WHERE username = ?";
$stmt = $mysqli->prepare($check_admin_sql);
$stmt->bind_param("s", $admin_username);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    $insert_admin_sql = "INSERT INTO `admin` (username, password) VALUES (?, ?)";
    $stmt_insert = $mysqli->prepare($insert_admin_sql);
    $stmt_insert->bind_param("ss", $admin_username, $admin_password);
    if ($stmt_insert->execute()) {
        echo "<p class='text-green-500 mt-4'><i class='fas fa-check-circle mr-2'></i>Default admin user '{$admin_username}' created successfully (Password: admin123).</p>";
    } else {
        die("<p class='text-red-500'><i class='fas fa-times-circle mr-2'></i>Error inserting default admin: " . $stmt_insert->error . "</p>");
    }
    $stmt_insert->close();
} else {
    echo "<p class='text-blue-400 mt-4'><i class='fas fa-info-circle mr-2'></i>Default admin user '{$admin_username}' already exists.</p>";
}
$stmt->close();


// Insert some sample games
$sample_games = [
    ['Spin & Win', 'Spin the wheel to win points!', 10, 'spin_win.png'],
    ['Scratch Card', 'Scratch to reveal your prize!', 15, 'scratch_card.png'],
    ['Quiz Master', 'Answer questions and earn points!', 20, 'quiz_master.png']
];

echo "<h3 class='text-xl font-bold text-gray-200 mt-6 mb-3'>Sample Games:</h3>";
foreach ($sample_games as $game) {
    $check_game_sql = "SELECT id FROM `games` WHERE name = ?";
    $stmt = $mysqli->prepare($check_game_sql);
    $stmt->bind_param("s", $game[0]);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 0) {
        $insert_game_sql = "INSERT INTO `games` (name, description, base_points, image) VALUES (?, ?, ?, ?)";
        $stmt_insert_game = $mysqli->prepare($insert_game_sql);
        $stmt_insert_game->bind_param("ssis", $game[0], $game[1], $game[2], $game[3]);
        if ($stmt_insert_game->execute()) {
            echo "<p class='text-green-500 text-sm mb-1'><i class='fas fa-check-circle mr-1'></i>Sample game '{$game[0]}' added.</p>";
        } else {
            echo "<p class='text-red-500 text-sm mb-1'><i class='fas fa-times-circle mr-1'></i>Error adding sample game '{$game[0]}': " . $stmt_insert_game->error . "</p>";
        }
        $stmt_insert_game->close();
    } else {
        echo "<p class='text-blue-400 text-sm mb-1'><i class='fas fa-info-circle mr-1'></i>Sample game '{$game[0]}' already exists.</p>";
    }
    $stmt->close();
}


$mysqli->close();

echo "<p class='text-green-500 font-bold mt-8 mb-4'><i class='fas fa-check-double mr-2'></i>Installation complete. Redirecting to login page...</p>";
echo '</div></body></html>';
header("refresh:5;url=login.php"); // Redirect after 5 seconds
exit();
?>