<?php
require_once __DIR__ . '/Common/Config.php';
header('Content-Type: application/json');

if (!is_logged_in()) {
    echo json_encode(['status' => 'error', 'message' => 'Login required']);
    exit();
}

$user_id = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';

try {
    $conn->begin_transaction();

    // ૧. યુઝરનું વર્તમાન બેલેન્સ મેળવો
    $stmt = $conn->prepare("SELECT balance, registration_bonus_claimed FROM users WHERE id = ? FOR UPDATE");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user_data = $stmt->get_result()->fetch_assoc();
    $current_balance = $user_data['balance'];

    if ($action == 'claim') {
        // જો બોનસ પહેલેથી લઈ લીધું હોય તો
        if ($user_data['registration_bonus_claimed'] == 1) {
            throw new Exception("Bonus already claimed!");
        }
        
        $amount = 10.00;
        // બેલેન્સ વધારો અને ક્લેમ સ્ટેટસ ૧ કરો
        $update = $conn->prepare("UPDATE users SET balance = balance + ?, registration_bonus_claimed = 1 WHERE id = ?");
        $update->bind_param("di", $amount, $user_id);
        $source = "Registration Bonus";
    } 
    elseif ($action == 'withdraw') {
        $amount = floatval($_POST['amount']);
        if ($current_balance < $amount) {
            throw new Exception("Insignificant balance!");
        }
        // બેલેન્સ ઘટાડો
        $update = $conn->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $update->bind_param("di", $amount, $user_id);
        $source = "Withdrawal";
    } else {
        throw new Exception("Invalid action!");
    }

    $update->execute();

    // ૨. transactions ટેબલમાં એન્ટ્રી પાડો (તમારા ટેબલ સ્ટ્રક્ચર મુજબ)
    $log = $conn->prepare("INSERT INTO transactions (user_id, amount, type, source) VALUES (?, ?, ?, ?)");
    $type = ($action == 'claim') ? 'credit' : 'debit';
    $log->bind_param("idss", $user_id, $amount, $type, $source);
    $log->execute();

    $conn->commit();

    // ૩. નવું ફાઈનલ બેલેન્સ મેળવો
    $res = $conn->query("SELECT balance FROM users WHERE id = $user_id")->fetch_assoc();
    $final_balance = number_format($res['balance'], 2);

    echo json_encode([
        'status' => 'success', 
        'new_balance' => $final_balance,
        'message' => 'Success!'
    ]);

} catch (Exception $e) {
    if(isset($conn)) $conn->rollback();
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
