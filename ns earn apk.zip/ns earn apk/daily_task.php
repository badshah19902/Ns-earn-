<?php
require_once __DIR__ . '/Common/Config.php';

if (!is_logged_in()) {
    header("Location: Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_claimed = 0;
$db_error = false;

try {
    // રજીસ્ટ્રેશન બોનસ ચેક
    $check_query = "SELECT registration_bonus_claimed FROM users WHERE id = ?";
    $stmt = $conn->prepare($check_query);
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $is_claimed = $res['registration_bonus_claimed'] ?? 0;
    }

    // એડમિન પેનલ દ્વારા ઉમેરેલા ટાસ્ક ડેટાબેઝમાંથી લેવા માટે
    // ખાતરી કરો કે તમારા ડેટાબેઝમાં 'tasks' ટેબલ છે
    $task_res = $conn->query("SELECT * FROM tasks ORDER BY id DESC");
    $dynamic_tasks = [];
    if ($task_res) {
        while($row = $task_res->fetch_assoc()) {
            $dynamic_tasks[] = $row;
        }
    }
} catch (Exception $e) { $db_error = true; }

require_once __DIR__ . '/Common/header.php';
?>

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<div class="min-h-screen bg-[#0b0f1a] pb-24 font-sans text-slate-300">
    
    <div class="bg-[#161d2f] pt-12 pb-10 px-6 rounded-b-[2.5rem] border-b border-white/5 shadow-2xl relative overflow-hidden">
        <div class="absolute top-0 right-0 w-32 h-32 bg-blue-600/10 rounded-full blur-3xl"></div>
        <h1 class="text-2xl font-black text-white uppercase tracking-tighter italic relative z-10">Earning Missions</h1>
        <p class="text-[10px] text-blue-500 font-bold uppercase tracking-[0.2em] mt-1 relative z-10">Complete tasks & earn real cash</p>
    </div>

    <div class="px-6 mt-8 space-y-4">
        
        <div class="bg-[#1e293b] p-5 rounded-[2rem] border border-white/10 flex items-center justify-between shadow-xl">
            <div class="flex items-center gap-4">
                <div class="w-12 h-12 bg-blue-600/10 rounded-2xl flex items-center justify-center text-blue-500 border border-blue-500/20 shadow-inner">
                    <i class="fas fa-gift text-xl"></i>
                </div>
                <div>
                    <h3 class="text-sm font-black text-white uppercase italic">Registration</h3>
                    <p class="text-[10px] text-slate-500 font-bold">+10 Points</p>
                </div>
            </div>
            <?php if ($is_claimed == 1): ?>
                <button disabled class="bg-slate-800 text-slate-500 px-5 py-2 rounded-xl text-[10px] font-black uppercase">Claimed</button>
            <?php else: ?>
                <button onclick="receiveBonus()" id="claimBtn" class="bg-blue-600 text-white px-5 py-2 rounded-xl text-[10px] font-black uppercase shadow-lg active:scale-95 transition">Receive</button>
            <?php endif; ?>
        </div>

        <?php foreach ($dynamic_tasks as $task): ?>
        <div class="relative group">
            <?php if(isset($task['is_premium']) && $task['is_premium']): ?>
                <div class="absolute -inset-0.5 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-[2rem] blur opacity-20"></div>
            <?php endif; ?>
            
            <div class="relative bg-[#1e293b] p-5 rounded-[2rem] border border-white/10 flex items-center justify-between shadow-xl">
                <div class="flex items-center gap-4">
                    <div class="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-500 border border-blue-500/20">
                        <i class="<?= $task['icon'] ?? 'fas fa-tasks' ?> text-xl"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-black text-white uppercase italic"><?= htmlspecialchars($task['title']) ?></h3>
                        <p class="text-[9px] text-slate-500 font-bold uppercase"><?= htmlspecialchars($task['description']) ?></p>
                        <p class="text-[10px] text-green-500 font-black mt-0.5 tracking-widest">+₹<?= $task['reward'] ?> INSTANT</p>
                    </div>
                </div>
                <button onclick="startTask('<?= $task['link'] ?>', '<?= $task['id'] ?>', <?= $task['reward'] ?>)" 
                        class="bg-slate-700 text-white px-5 py-2.5 rounded-xl text-[10px] font-black uppercase transition active:scale-95 shadow-lg">
                    Go Task
                </button>
            </div>
        </div>
        <?php endforeach; ?>

    </div>

    <div id="verifyModal" class="hidden fixed inset-0 z-[100] flex items-center justify-center px-6 backdrop-blur-md bg-black/80">
        <div class="bg-[#161d2f] w-full max-w-sm rounded-[3rem] p-8 border border-white/10 text-center shadow-2xl">
            <div class="w-16 h-16 bg-yellow-500/20 text-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4 border border-yellow-500/20">
                <i class="fas fa-shield-check text-2xl"></i>
            </div>
            <h2 class="text-xl font-black text-white uppercase italic mb-2 tracking-tighter">Task Verification</h2>
            <p class="text-slate-400 text-[10px] uppercase font-bold tracking-widest leading-relaxed mb-6 px-2">
                After clicking claim, our system will verify your task. If found <span class="text-red-500">fraud/unfollowed</span>, points will be deducted.
            </p>
            <button id="claimTaskBtn" class="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-2xl text-[11px] font-black uppercase shadow-lg shadow-blue-900/40 active:scale-95 transition">
                Task Completed, Claim Now
            </button>
        </div>
    </div>
</div>

<script>
let tempTaskId = '';
let tempPoints = 0;

function startTask(link, id, points) {
    tempTaskId = id;
    tempPoints = points;
    window.open(link, '_blank');
    setTimeout(() => {
        document.getElementById('verifyModal').classList.remove('hidden');
    }, 2000);
}

document.getElementById('claimTaskBtn').onclick = function() {
    this.disabled = true;
    this.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Verifying...';
    
    fetch('claim_task_points.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `task_id=${tempTaskId}&points=${tempPoints}`
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message);
        location.reload();
    })
    .catch(() => {
        alert("Task request sent for verification.");
        location.reload();
    });
};

function receiveBonus() {
    fetch('claim_bonus.php')
    .then(res => res.json())
    .then(data => {
        alert(data.message);
        location.reload();
    });
}
</script>

<?php require_once __DIR__ . '/Common/bottom.php'; ?>
