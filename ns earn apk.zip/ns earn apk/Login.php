<?php
require_once __DIR__ . '/Common/Config.php';

// જો યુઝર પહેલેથી લોગિન હોય તો હોમ પેજ પર મોકલી દો
if (is_logged_in()) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NS Earn - Premium Access</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .glass {
            background: rgba(22, 29, 47, 0.7);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .neo-glow {
            box-shadow: 0 0 20px rgba(59, 130, 246, 0.3);
        }
        input:focus {
            box-shadow: 0 0 15px rgba(59, 130, 246, 0.5);
        }
        .toggle-password {
            cursor: pointer;
            transition: color 0.3s;
        }
        .toggle-password:hover {
            color: #3b82f6;
        }
    </style>
</head>
<body class="bg-[#0b0f1a] text-white font-sans min-h-screen flex items-center justify-center p-6 overflow-hidden">

    <div class="fixed top-[-10%] left-[-10%] w-64 h-64 bg-blue-600/20 rounded-full blur-[100px]"></div>
    <div class="fixed bottom-[-10%] right-[-10%] w-80 h-80 bg-purple-600/20 rounded-full blur-[100px]"></div>

    <div class="max-w-md w-full relative z-10">
        <div class="text-center mb-10">
            <h1 class="text-5xl font-black italic tracking-tighter bg-clip-text text-transparent bg-gradient-to-b from-blue-400 to-blue-700 drop-shadow-2xl">
                NS EARN
            </h1>
            <p class="text-slate-500 text-xs font-bold uppercase tracking-[0.3em] mt-2">Premium Gaming Portal</p>
        </div>

        <div class="glass p-8 rounded-[3rem] shadow-[0_25px_50px_rgba(0,0,0,0.5)] relative overflow-hidden">
            
            <div class="flex bg-black/30 p-1.5 rounded-2xl mb-8">
                <button onclick="switchTab('login')" id="loginTab" class="w-1/2 py-3 rounded-xl font-black text-sm transition-all duration-300 bg-blue-600 shadow-lg">LOGIN</button>
                <button onclick="switchTab('signup')" id="signupTab" class="w-1/2 py-3 rounded-xl font-black text-sm text-slate-400 transition-all duration-300">SIGNUP</button>
            </div>

            <form id="loginForm" action="process_login.php" method="POST" class="space-y-6">
                <div class="space-y-2">
                    <label class="text-xs font-bold text-slate-400 uppercase ml-2">Mobile Number</label>
                    <div class="relative group">
                        <i class="fas fa-phone absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-500 transition"></i>
                        <input type="number" name="mobile" required placeholder="Enter Mobile Number" 
                               class="w-full bg-black/40 border border-white/5 rounded-2xl py-4 pl-14 pr-12 outline-none transition-all duration-300">
                    </div>
                </div>

                <div class="space-y-2">
                    <label class="text-xs font-bold text-slate-400 uppercase ml-2">Password</label>
                    <div class="relative group">
                        <i class="fas fa-lock absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-500 transition"></i>
                        <input type="password" id="loginPassword" name="password" required placeholder="••••••••" 
                               class="w-full bg-black/40 border border-white/5 rounded-2xl py-4 pl-14 pr-12 outline-none transition-all duration-300">
                        <i class="fas fa-eye absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 toggle-password" onclick="togglePass('loginPassword', this)"></i>
                    </div>
                </div>

                <div class="space-y-4">
                    <button type="submit" class="w-full py-5 bg-gradient-to-r from-blue-500 to-blue-700 rounded-2xl font-black shadow-xl shadow-blue-500/20 transform active:scale-95 transition-all">
                        LOG IN NOW
                    </button>
                    
                    <div class="text-center">
                        <a href="forgot_password.php" class="text-xs font-bold text-blue-400 uppercase tracking-widest hover:text-blue-300 transition-all">
                            Forgot Password?
                        </a>
                    </div>
                </div>
            </form>

            <form id="signupForm" action="process_signup.php" method="POST" onsubmit="return validateSignup()" class="space-y-6 hidden">
                <div class="space-y-2">
                    <label class="text-xs font-bold text-slate-400 uppercase ml-2">Mobile Number</label>
                    <input type="number" name="mobile" required placeholder="Enter Mobile Number" 
                           class="w-full bg-black/40 border border-white/5 rounded-2xl py-4 px-6 outline-none">
                </div>
                <div class="space-y-2">
                    <label class="text-xs font-bold text-slate-400 uppercase ml-2">Username</label>
                    <input type="text" name="username" required placeholder="Set Display Name" 
                           class="w-full bg-black/40 border border-white/5 rounded-2xl py-4 px-6 outline-none">
                </div>
                <div class="space-y-2">
                    <label class="text-xs font-bold text-slate-400 uppercase ml-2">Set Password</label>
                    <div class="relative">
                        <input type="password" id="signupPassword" name="password" required minlength="6" placeholder="Min. 6 Characters" 
                               class="w-full bg-black/40 border border-white/5 rounded-2xl py-4 pl-6 pr-12 outline-none transition-all">
                        <i class="fas fa-eye absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 toggle-password" onclick="togglePass('signupPassword', this)"></i>
                    </div>
                    <p id="passError" class="text-[10px] text-red-500 font-bold uppercase ml-2 hidden">Password must be at least 6 characters!</p>
                </div>
                <button type="submit" class="w-full py-5 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-2xl font-black shadow-xl shadow-purple-500/20 transform active:scale-95 transition-all">
                    CREATE ACCOUNT
                </button>
            </form>
        </div>

        <p class="text-center mt-8 text-slate-500 text-xs font-bold uppercase tracking-widest">
            Having trouble? <a href="http://t.me/NsEarnpvt" target="_blank" class="text-blue-400">Contact Support</a>
        </p>
    </div>

    <script>
        function switchTab(type) {
            const loginForm = document.getElementById('loginForm');
            const signupForm = document.getElementById('signupForm');
            const loginTab = document.getElementById('loginTab');
            const signupTab = document.getElementById('signupTab');

            if (type === 'login') {
                loginForm.classList.remove('hidden');
                signupForm.classList.add('hidden');
                loginTab.classList.add('bg-blue-600', 'shadow-lg');
                loginTab.classList.remove('text-slate-400');
                signupTab.classList.remove('bg-purple-600', 'shadow-lg');
                signupTab.classList.add('text-slate-400');
            } else {
                loginForm.classList.add('hidden');
                signupForm.classList.remove('hidden');
                signupTab.classList.add('bg-purple-600', 'shadow-lg');
                signupTab.classList.remove('text-slate-400');
                loginTab.classList.remove('bg-blue-600', 'shadow-lg');
                loginTab.classList.add('text-slate-400');
            }
        }

        // Signup Validation for 6 characters
        function validateSignup() {
            const pass = document.getElementById('signupPassword').value;
            const errorMsg = document.getElementById('passError');
            if (pass.length < 6) {
                errorMsg.classList.remove('hidden');
                return false;
            }
            errorMsg.classList.add('hidden');
            return true;
        }

        function togglePass(inputId, icon) {
            const passInput = document.getElementById(inputId);
            if (passInput.type === "password") {
                passInput.type = "text";
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passInput.type = "password";
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
