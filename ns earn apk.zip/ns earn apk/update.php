<?php
// ૧. ડેટાબેઝ કનેક્શન વિગતો
$host = "gateway01.ap-southeast-1.prod.aws.tidbcloud.com";
$port = 4000;
$user = "46m77PoyYUsETRu.root";
$pass = "તમારો_પાસવર્ડ"; // તમે Reset કરીને મેળવેલો પાસવર્ડ અહીં નાખો
$dbname = "test";

$conn = mysqli_init();
mysqli_ssl_set($conn, NULL, NULL, NULL, NULL, NULL); // SSL કનેક્શન

if (!mysqli_real_connect($conn, $host, $user, $pass, $dbname, $port)) {
    die("Connection failed: " . mysqli_connect_error());
}

// ૨. એપમાંથી આવતા ડેટાને પકડવા માટે (GET અથવા POST)
if(isset($_GET['username']) && isset($_GET['amount'])) {
    $uname = $_GET['username'];
    $amt = $_GET['amount'];

    // ડેટા અપડેટ કરવાની ક્વેરી
    $sql = "UPDATE users SET balance = balance + $amt WHERE username = '$uname'";

    if (mysqli_query($conn, $sql)) {
        echo "Success: Balance Updated!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    echo "Waiting for data...";
}
?>
