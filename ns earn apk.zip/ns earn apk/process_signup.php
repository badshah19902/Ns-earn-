<?php
require_once __DIR__ . '/Common/Config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    // ૧. ટેબલમાં 'phone' કોલમ છે કે નહીં તે ચેક કરીને ક્વેરી રન કરવી
    try {
        $check_user = $conn->query("SELECT id FROM users WHERE phone = '$mobile'");
        
        if ($check_user && $check_user->num_rows > 0) {
            die("<script>alert('આ મોબાઈલ નંબર પહેલેથી રજિસ્ટર્ડ છે!'); window.location='Login.php';</script>");
        } else {
            // ૨. પાસવર્ડ હેશિંગ
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // ૩. ડેટા ઈન્સર્ટ કરવો
            $sql = "INSERT INTO users (username, phone, password, balance, today_points, refer_earn) VALUES (?, ?, ?, 0, 0, 0)";
            $stmt = $conn->prepare($sql);
            
            if ($stmt) {
                $stmt->bind_param("sss", $username, $mobile, $hashed_password);
                if ($stmt->execute()) {
                    echo "<script>alert('રજિસ્ટ્રેશન સફળ! હવે લોગિન કરો.'); window.location='Login.php';</script>";
                } else {
                    echo "Error: " . $stmt->error;
                }
            } else {
                echo "Database Error: " . $conn->error;
            }
        }
    } catch (mysqli_sql_exception $e) {
        // જો કોલમ ન હોય તો આ મેસેજ દેખાશે
        echo "<div style='color:red; padding:20px; background:#fff;'>
                <b>Database Error:</b> 'phone' કોલમ મળતી નથી. <br>
                મહેરબાની કરીને phpMyAdmin માં જઈને <code>ALTER TABLE users ADD COLUMN phone VARCHAR(15) AFTER username;</code> રન કરો.
              </div>";
    }
}
?>
