<?php
/**
 * NS Earn - Premium Games Hub
 */

require_once __DIR__ . '/Common/Config.php';

// લોગિન ચેક
if (!is_logged_in()) {
    header("Location: Login.php");
    exit();
}

require_once __DIR__ . '/Common/header.php';

// તમારી પસંદગીની ૫ પ્રીમિયમ ગેમ્સ
$premium_games = [
    [
        'id' => 1,
        'name' => 'Ludo Master',
        'desc' => 'Classic board game with friends',
        'icon' => 'fa-th-large',
        'color' => 'from-red-500 to-orange-500',
        'link' => 'games/ludo.php'
    ],
    [
        'id' => 2,
        'name' => 'Block Puzzle',
        'desc' => 'Sharp your mind with blocks',
        'icon' => 'fa-puzzle-piece',
        'color' => 'from-blue-500 to-cyan-500',
        'link' => 'games/puzzle.php'
    ],
    [
        'id' => 3,
        'name' => 'Candy Crush',
        'desc' => 'Match sweets to win rewards',
        'icon' => 'fa-candy-cane',
        'color' => 'from-pink-500 to-purple-600',
        'link' => 'games/candy.php'
    ],
    [
        'id' => 4,
        'name' => 'Classic Snake',
        'desc' => 'Retro snake game fun',
        'icon' => 'fa-worm',
        'color' => 'from-green-500 to-emerald-600',
        'link' => 'games/snake.php'
    ],
    [
        'id' => 5,
        'name' => 'Lucky Spin',
        'desc' => 'Spin the wheel, try your luck',
        'icon' => 'fa-dharmachakra',
        'color' => 'from-yellow-400 to-orange-600',
        'link' => 'games/spin.php'
    ]
];
?>

<div class="min-h-screen bg-[#0b0f1a] pb-24 text-white font-sans">
    
    <div class="bg-gradient-to-br from-[#1e293b] to-[#0f172a] p-10 rounded-b-[3.5rem] shadow-2xl border-b border-white/5">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-black bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-emerald-400">PREMIUM GAMES</h1>
                <p class="text-slate-400 text-xs mt-1 uppercase tracking-widest font-bold">Select your challenge</p>
            </div>
            <div class="bg-white/5 p-3 rounded-2xl backdrop-blur-md">
                <i class="fas fa-gamepad text-2xl text-blue-500"></i>
            </div>
        </div>
    </div>

    <div class="px-6 -mt-8">
        <a href="<?= $premium_games[4]['link'] ?>" class="block relative h-44 rounded-[2.5rem] overflow-hidden shadow-2xl group transition-all duration-500 hover:scale-[1.02]">
            <div class="absolute inset-0 bg-gradient-to-r <?= $premium_games[4]['color'] ?> opacity-90 group-hover:opacity-100 transition"></div>
            <div class="absolute inset-0 flex items-center justify-between px-8">
                <div>
                    <span class="bg-white/20 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-tighter">Featured Game</span>
                    <h2 class="text-2xl font-black mt-1"><?= $premium_games[4]['name'] ?></h2>
                    <p class="text-white/70 text-xs mt-1"><?= $premium_games[4]['desc'] ?></p>
                </div>
                <i class="fas <?= $premium_games[4]['icon'] ?> text-6xl text-white/20"></i>
            </div>
        </a>
    </div>

    <div class="px-6 mt-10 space-y-4">
        <h3 class="text-slate-500 text-[10px] font-bold uppercase tracking-[0.3em] ml-2">All Adventures</h3>
        
        <?php foreach(array_slice($premium_games, 0, 4) as $game): ?>
        <a href="<?= $game['link'] ?>" class="flex items-center gap-5 p-4 bg-[#1e293b]/40 border border-white/5 rounded-[2rem] hover:bg-[#1e293b]/70 transition-all group">
            <div class="w-16 h-16 bg-gradient-to-br <?= $game['color'] ?> rounded-2xl flex items-center justify-center text-2xl shadow-lg group-hover:rotate-12 transition duration-300">
                <i class="fas <?= $game['icon'] ?>"></i>
            </div>
            <div class="flex-1">
                <h4 class="font-bold text-lg text-slate-100"><?= $game['name'] ?></h4>
                <p class="text-slate-400 text-[10px]"><?= $game['desc'] ?></p>
            </div>
            <div class="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center text-slate-500 group-hover:text-white transition">
                <i class="fas fa-play text-xs"></i>
            </div>
        </a>
        <?php endforeach; ?>
    </div>

</div>

<?php require_once __DIR__ . '/Common/bottom.php'; ?>
