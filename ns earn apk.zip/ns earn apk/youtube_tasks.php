<?php
require_once __DIR__ . '/Common/Config.php';
require_once __DIR__ . '/Common/header.php';
?>

<div class="min-h-screen bg-black flex flex-col overflow-hidden" style="height: 100vh;">
    
    <div class="p-4 bg-[#0f0f0f] border-b border-white/5 flex justify-between items-center z-50">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-red-600 rounded-xl flex items-center justify-center shadow-lg shadow-red-600/20">
                <i class="fab fa-youtube text-white text-xl"></i>
            </div>
            <div>
                <h2 class="text-white font-black text-sm uppercase tracking-tighter">NS YouTube</h2>
                <div class="flex items-center gap-1">
                    <span class="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></span>
                    <span class="text-[9px] text-gray-400 font-bold uppercase tracking-widest">Desktop Mode</span>
                </div>
            </div>
        </div>
        <div class="flex gap-2">
             <button onclick="document.getElementById('yt-frame').src='https://m.youtube.com'" class="w-9 h-9 bg-white/5 rounded-xl flex items-center justify-center text-white">
                <i class="fas fa-home text-xs"></i>
             </button>
             <a href="index.php" class="w-9 h-9 bg-red-500/10 rounded-xl flex items-center justify-center text-red-500">
                <i class="fas fa-times text-xs"></i>
             </a>
        </div>
    </div>

    <div class="flex-grow relative bg-black">
        <div id="yt-loader" class="absolute inset-0 flex flex-col items-center justify-center bg-[#0f0f0f] z-40 transition-opacity duration-500">
            <div class="w-12 h-12 border-4 border-red-600/20 border-t-red-600 rounded-full animate-spin mb-4"></div>
            <p class="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em]">Loading YouTube Experience...</p>
        </div>

        <iframe 
            src="https://m.youtube.com/?itct=sm" 
            id="yt-frame"
            class="w-full h-full border-none shadow-2xl"
            style="height: calc(100vh - 80px);"
            allow="autoplay; encrypted-media; picture-in-picture"
            allowfullscreen
            onload="hideYTLoader()"
        ></iframe>
    </div>
</div>

<script>
    function hideYTLoader() {
        const loader = document.getElementById('yt-loader');
        loader.style.opacity = '0';
        setTimeout(() => {
            loader.style.display = 'none';
        }, 500);
    }
</script>

<?php require_once __DIR__ . '/Common/bottom.php'; ?>
