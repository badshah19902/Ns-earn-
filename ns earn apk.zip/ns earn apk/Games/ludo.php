<!DOCTYPE html>
<html lang="gu">
<head>
    <meta charset="UTF-8">
    <title>Professional Ludo - Computer vs User</title>
    <style>
        :root {
            --red: #ff0000; --green: #00b050; --yellow: #ffc000; --blue: #0070c0;
            --white: #ffffff; --border: #333;
        }
        body { background: #1a1a1a; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; font-family: sans-serif; }
        #ludo-board { 
            display: grid; grid-template-columns: repeat(15, 40px); grid-template-rows: repeat(15, 40px);
            background: var(--white); border: 10px solid #444; box-shadow: 0 0 50px rgba(0,0,0,0.5);
        }
        .cell { border: 1px solid #ccc; position: relative; display: flex; justify-content: center; align-items: center; }
        
        /* Bases */
        .base-green { grid-area: 1/1/7/7; background: var(--green); }
        .base-yellow { grid-area: 1/10/7/16; background: var(--yellow); }
        .base-red { grid-area: 10/1/16/7; background: var(--red); }
        .base-blue { grid-area: 10/10/16/16; background: var(--blue); }
        
        /* Home Paths */
        .home-red { background: var(--red) !important; }
        .home-green { background: var(--green) !important; }
        
        /* Center Area */
        .center { grid-area: 7/7/10/10; background: #eee; position: relative; overflow: hidden; }
        .triangle { position: absolute; width: 0; height: 0; border-style: solid; }
        .t-red { border-width: 0 60px 60px 60px; border-color: transparent transparent var(--red) transparent; bottom: 0; }
        
        /* Pieces */
        .token { width: 30px; height: 30px; border-radius: 50%; border: 3px solid white; box-shadow: 0 4px 6px rgba(0,0,0,0.3); z-index: 10; transition: all 0.4s ease; }
        .token-user { background: var(--red); }
        .token-ai { background: var(--green); }
        
        .controls { position: absolute; right: 50px; color: white; text-align: center; }
        .dice { font-size: 50px; background: white; color: black; padding: 10px; border-radius: 10px; cursor: pointer; }
    </style>
</head>
<body>

<div id="ludo-board">
    <div class="base-green"></div><div class="base-yellow"></div>
    <div class="base-red"></div><div class="base-blue"></div>
    
    <div class="center">
        <div class="triangle t-red"></div>
    </div>
</div>

<div class="controls">
    <h2 id="turn-text">તમારો વારો</h2>
    <div id="dice-result" class="dice" onclick="playerMove()">🎲</div>
    <p id="status">પાસો ફેંકો!</p>
</div>

<script>
    // Game Config
    let winRate = 0.8; // 80% Win Rate for AI
    let userTokens = [0, 0, 0, 0]; // Position 0 means Home
    let aiTokens = [0, 0, 0, 0];
    let turn = 'USER';

    function getDiceRoll(isAI) {
        if (isAI && Math.random() < winRate) {
            return Math.random() < 0.5 ? 6 : 5; // AI ને 5 અથવા 6 મળવાની શક્યતા વધુ
        }
        return Math.floor(Math.random() * 6) + 1;
    }

    async function playerMove() {
        if(turn !== 'USER') return;
        
        let roll = getDiceRoll(false);
        document.getElementById('dice-result').innerText = roll;
        
        // Logic: જો 6 આવે તો એક ટોકન બહાર કાઢો અથવા જે બહાર હોય તેને ખસેડો
        // (અહીં સીધું લોજિક મૂક્યું છે, રિયલ એપમાં ક્લિક ઇવેન્ટ આવશે)
        document.getElementById('status').innerText = "તમે " + roll + " ફેંક્યા";
        
        turn = 'AI';
        setTimeout(aiMove, 1500);
    }

    function aiMove() {
        let roll = getDiceRoll(true);
        document.getElementById('dice-result').innerText = roll;
        document.getElementById('status').innerText = "AI એ " + roll + " ફેંક્યા";
        
        // Priority AI Logic
        // 1. Kill logic check (Placeholder)
        // 2. If 6, bring out token
        // 3. Move closest to home
        
        turn = 'USER';
        document.getElementById('status').innerText = "તમારો વારો!";
    }
</script>
</body>
</html>
